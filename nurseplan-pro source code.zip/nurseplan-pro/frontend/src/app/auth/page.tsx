"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Stethoscope, Lock, Mail, User, ShieldCheck, School, GraduationCap, ChevronRight, Activity, ArrowLeft } from "lucide-react";

function AuthContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  
  const [tab, setTab] = useState<"login" | "signup">("login");
  const [role, setRole] = useState<"student" | "instructor" | "school_admin">("student");
  
  // Input fields
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [schoolName, setSchoolName] = useState(""); // For new school admin
  const [enrollmentNumber, setEnrollmentNumber] = useState(""); // For student
  const [employeeId, setEmployeeId] = useState(""); // For instructor
  const [department, setDepartment] = useState(""); // For instructor
  
  // MFA flow
  const [mfaRequired, setMfaRequired] = useState(false);
  const [mfaUserId, setMfaUserId] = useState("");
  const [mfaCode, setMfaCode] = useState("");
  
  // Password Reset flow
  const [resetFlow, setResetFlow] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  // Status/Error messages
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");

  useEffect(() => {
    const isSignup = searchParams.get("signup") === "true";
    const paramRole = searchParams.get("role");
    if (isSignup) setTab("signup");
    if (paramRole === "school_admin" || paramRole === "instructor" || paramRole === "student") {
      setRole(paramRole as any);
    }
  }, [searchParams]);

  // Handle Form Submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    const baseUrl = "http://localhost:5000/api";

    try {
      if (resetFlow) {
        // Password Reset Request
        const res = await fetch(`${baseUrl}/auth/reset-password`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Password reset failed");
        setResetSent(true);
        setSuccess("Password reset instructions have been sent to your email.");
      } else if (mfaRequired) {
        // MFA Verification
        const res = await fetch(`${baseUrl}/auth/mfa/verify`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId: mfaUserId, code: mfaCode })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Invalid MFA code");
        
        // Save token and route
        localStorage.setItem("nurseplan_token", data.token);
        localStorage.setItem("nurseplan_user", JSON.stringify(data.user));
        routeUser(data.user.role);
      } else if (tab === "login") {
        // Standard Login
        const res = await fetch(`${baseUrl}/auth/login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Login credentials invalid");

        if (data.mfaRequired) {
          setMfaRequired(true);
          setMfaUserId(data.userId);
        } else {
          localStorage.setItem("nurseplan_token", data.token);
          localStorage.setItem("nurseplan_user", JSON.stringify(data.user));
          routeUser(data.user.role);
        }
      } else {
        // Register User
        const body = {
          email,
          password,
          name,
          role,
          schoolName: role === "school_admin" ? schoolName : undefined,
          schoolId: role !== "school_admin" ? "sch-001" : undefined, // default Greenfield Nursing College for students/instructors
          enrollmentNumber: role === "student" ? enrollmentNumber : undefined,
          employeeId: role === "instructor" ? employeeId : undefined,
          department: role === "instructor" ? department : undefined,
        };

        const res = await fetch(`${baseUrl}/auth/register`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Registration details invalid");

        setSuccess("Account registered! Logging you in...");
        setTimeout(() => {
          localStorage.setItem("nurseplan_token", data.token);
          localStorage.setItem("nurseplan_user", JSON.stringify(data.user));
          routeUser(data.user.role);
        }, 1500);
      }
    } catch (err: any) {
      setError(err.message || "An unexpected network error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const routeUser = (userRole: string) => {
    if (userRole === "student") router.push("/student");
    else if (userRole === "instructor") router.push("/instructor");
    else if (userRole === "school_admin") router.push("/admin");
    else if (userRole === "system_admin") router.push("/admin");
  };

  return (
    <div className="flex-1 flex items-center justify-center min-h-screen bg-gradient-to-br from-brand-50 via-slate-50 to-brand-100/30 p-4">
      <div className="w-full max-w-md bg-white rounded-3xl border border-slate-200/60 shadow-2xl p-8 space-y-6 animate-slide-up relative">
        
        {/* Back Link */}
        <Link href="/" className="absolute top-6 left-6 text-slate-400 hover:text-slate-600 flex items-center gap-1 text-xs font-semibold">
          <ArrowLeft className="w-3.5 h-3.5" /> Back Home
        </Link>

        {/* Brand Identity */}
        <div className="text-center pt-4">
          <div className="inline-flex w-12 h-12 rounded-2xl bg-brand-600 text-white items-center justify-center shadow-lg shadow-brand-500/20 mb-3">
            <Stethoscope className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-800 font-sans">
            {resetFlow ? "Reset Password" : mfaRequired ? "Two-Factor Verification" : tab === "login" ? "Sign In" : "Create Account"}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {resetFlow 
              ? "Retrieve credentials via secure link" 
              : mfaRequired 
              ? "Enter the 6-digit code from your authenticator app" 
              : tab === "login" 
              ? "Access your dashboard to manage clinical goals" 
              : "Standardize your clinical logbooks and documentation"}
          </p>
        </div>

        {/* Action errors/successes */}
        {error && (
          <div className="p-3 bg-rose-50 border border-rose-100 text-rose-700 text-xs font-medium rounded-xl">
            {error}
          </div>
        )}
        {success && (
          <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-medium rounded-xl">
            {success}
          </div>
        )}

        {/* Tab Selection */}
        {!resetFlow && !mfaRequired && (
          <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => { setTab("login"); setError(""); }}
              className={`py-2 text-xs font-bold rounded-lg transition-all ${tab === "login" ? "bg-white text-brand-700 shadow" : "text-slate-500 hover:text-slate-700"}`}
            >
              Sign In
            </button>
            <button
              onClick={() => { setTab("signup"); setError(""); }}
              className={`py-2 text-xs font-bold rounded-lg transition-all ${tab === "signup" ? "bg-white text-brand-700 shadow" : "text-slate-500 hover:text-slate-700"}`}
            >
              Sign Up
            </button>
          </div>
        )}

        {/* Form Fields */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {resetFlow ? (
            /* Forgot Password */
            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-600 block">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  required
                  placeholder="name@nursingschool.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 text-sm"
                />
              </div>
            </div>
          ) : mfaRequired ? (
            /* MFA Verification */
            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-600 block">MFA Code</label>
              <div className="relative">
                <ShieldCheck className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  maxLength={6}
                  placeholder="123456"
                  value={mfaCode}
                  onChange={(e) => setMfaCode(e.target.value)}
                  className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 text-center tracking-widest text-sm font-bold"
                />
              </div>
              <p className="text-[10px] text-slate-400 italic text-center">Tip: For mock testing, you can input '123456'</p>
            </div>
          ) : (
            /* Main Register/Login forms */
            <div className="space-y-3.5">
              {/* Signup Name */}
              {tab === "signup" && (
                <>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        required
                        placeholder="John Doe, BSN"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 focus:outline-none focus:border-brand-500 text-sm"
                      />
                    </div>
                  </div>

                  {/* Signup Role selector */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">System Role</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(["student", "instructor", "school_admin"] as const).map((r) => (
                        <button
                          key={r}
                          type="button"
                          onClick={() => setRole(r)}
                          className={`py-1.5 text-[10px] font-bold border rounded-lg transition-all capitalize ${role === r ? "bg-brand-50 border-brand-500 text-brand-700" : "border-slate-200 text-slate-500 bg-white"}`}
                        >
                          {r.replace("_", " ")}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Conditional role fields */}
                  {role === "student" && (
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 block">Enrollment Number</label>
                      <div className="relative">
                        <GraduationCap className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                        <input
                          type="text"
                          required
                          placeholder="ENR-2026-XXXX"
                          value={enrollmentNumber}
                          onChange={(e) => setEnrollmentNumber(e.target.value)}
                          className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 focus:outline-none focus:border-brand-500 text-sm"
                        />
                      </div>
                    </div>
                  )}

                  {role === "instructor" && (
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 block">Employee ID</label>
                        <input
                          type="text"
                          required
                          placeholder="EMP-XXXX"
                          value={employeeId}
                          onChange={(e) => setEmployeeId(e.target.value)}
                          className="w-full h-11 px-4 rounded-xl border border-slate-200 focus:outline-none focus:border-brand-500 text-sm"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 block">Department</label>
                        <input
                          type="text"
                          required
                          placeholder="Med-Surg Nursing"
                          value={department}
                          onChange={(e) => setDepartment(e.target.value)}
                          className="w-full h-11 px-4 rounded-xl border border-slate-200 focus:outline-none focus:border-brand-500 text-sm"
                        />
                      </div>
                    </div>
                  )}

                  {role === "school_admin" && (
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 block">Nursing College Name</label>
                      <div className="relative">
                        <School className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                        <input
                          type="text"
                          required
                          placeholder="Greenfield Nursing School"
                          value={schoolName}
                          onChange={(e) => setSchoolName(e.target.value)}
                          className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 focus:outline-none focus:border-brand-500 text-sm"
                        />
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* Email Address */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    placeholder="email@nursingschool.edu"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 focus:outline-none focus:border-brand-500 text-sm"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-600 block">Password</label>
                  {tab === "login" && (
                    <button
                      type="button"
                      onClick={() => setResetFlow(true)}
                      className="text-xs text-brand-600 hover:underline font-semibold"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 focus:outline-none focus:border-brand-500 text-sm"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Submit Action */}
          <button
            type="submit"
            disabled={loading}
            className="w-full h-11 bg-brand-600 hover:bg-brand-700 disabled:bg-brand-400 text-white font-bold rounded-xl transition-all shadow-md shadow-brand-600/10 flex items-center justify-center gap-2 text-sm mt-6"
          >
            {loading ? (
              <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : resetFlow ? (
              "Send Reset Link"
            ) : mfaRequired ? (
              "Verify Code"
            ) : tab === "login" ? (
              "Sign In"
            ) : (
              "Create Account"
            )}
            {!loading && <ChevronRight className="w-4 h-4" />}
          </button>
        </form>

        {/* Footer controls */}
        {resetFlow && (
          <button
            onClick={() => { setResetFlow(false); setResetSent(false); setError(""); }}
            className="w-full text-center text-xs text-slate-500 hover:text-slate-700 font-semibold"
          >
            Back to Sign In
          </button>
        )}

        {/* Mock testing helper banner */}
        {!resetFlow && !mfaRequired && tab === "login" && (
          <div className="mt-4 p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
            <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Developer Quick Logins</h4>
            <div className="flex flex-wrap gap-1">
              <button
                type="button"
                onClick={() => { setEmail("john.doe@greenfield.edu"); setPassword("password123"); }}
                className="text-[9px] bg-brand-50 text-brand-700 border border-brand-200/50 rounded px-1.5 py-0.5 font-semibold"
              >
                Student Login
              </button>
              <button
                type="button"
                onClick={() => { setEmail("sarah.jenkins@greenfield.edu"); setPassword("password123"); }}
                className="text-[9px] bg-teal-50 text-teal-700 border border-teal-200/50 rounded px-1.5 py-0.5 font-semibold"
              >
                Instructor Login
              </button>
              <button
                type="button"
                onClick={() => { setEmail("admin@nurseplanpro.com"); setPassword("password123"); }}
                className="text-[9px] bg-purple-50 text-purple-700 border border-purple-200/50 rounded px-1.5 py-0.5 font-semibold"
              >
                Sys-Admin Login
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function AuthPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center bg-slate-50"><div className="w-8 h-8 border-4 border-brand-600 border-t-transparent rounded-full animate-spin"></div></div>}>
      <AuthContent />
    </Suspense>
  );
}
