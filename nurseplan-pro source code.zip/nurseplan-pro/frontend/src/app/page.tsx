"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  Activity, 
  Sparkles, 
  FileText, 
  CheckCircle2, 
  BookOpen, 
  ShieldCheck, 
  Users, 
  GraduationCap, 
  TrendingUp, 
  HelpCircle,
  Menu,
  X,
  ArrowRight,
  Stethoscope,
  Clock,
  ChevronDown
} from "lucide-react";

export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("student");
  const [faqOpen, setFaqOpen] = useState<number | null>(null);

  const testimonials = [
    {
      name: "Marcus Vance",
      role: "BSN Student, Greenfield College",
      image: "MV",
      content: "NursePlan Pro cut my care plan writing time in half! The SMART goal generator and AI rationales helped me understand the clinical connections much better."
    },
    {
      name: "Professor Anita Sterling, RN",
      role: "Clinical Instructor, St. Jude Academy",
      image: "AS",
      content: "Grading care plans used to take hours of red-penning. Now I can highlight areas, apply the standard rubric, and approve clinical logs digitally in clicks."
    },
    {
      name: "Dr. David Carter",
      role: "Dean of Nursing, Western State University",
      image: "DC",
      content: "Implementing NursePlan Pro across our program has standardized care plan quality and provided invaluable clinical competency dashboards for accreditation reports."
    }
  ];

  const FAQs = [
    {
      q: "Is NursePlan Pro HIPAA-compliant?",
      a: "Yes. To protect patient privacy, NursePlan Pro enforces strict data minimization. Students log patient details using initials only and are prohibited from uploading any personally identifiable health data."
    },
    {
      q: "Can nursing schools customize the grading rubrics?",
      a: "Yes, school administration accounts can customize rubric criteria, maximum scores, and assignment instructions to match their specific curricula."
    },
    {
      q: "Does the AI assistant write care plans for the student?",
      a: "No. The AI Diagnosis Assistant and SMART Goal Generator act as educational scaffolds. They analyze assessment data and offer suggestions and rationales, but students must refine, structure, and submit their own work."
    },
    {
      q: "Can I export care plans as PDFs?",
      a: "Absolutely. Students can export complete, professionally formatted care plans and procedure logbooks in one click for print or LMS upload."
    }
  ];

  return (
    <div className="flex-1 flex flex-col font-sans">
      {/* Header */}
      <header className="sticky top-0 z-50 glass-panel border-b border-slate-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-brand-600 flex items-center justify-center text-white shadow-lg shadow-brand-500/30">
              <Stethoscope className="w-6 h-6" />
            </div>
            <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-brand-700 to-brand-500 bg-clip-text text-transparent font-sans">
              NursePlan <span className="font-semibold text-brand-500">Pro</span>
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
            <a href="#features" className="hover:text-brand-600 transition-colors">Features</a>
            <a href="#pricing" className="hover:text-brand-600 transition-colors">Pricing</a>
            <a href="#faqs" className="hover:text-brand-600 transition-colors">FAQ</a>
            <Link href="/auth" className="hover:text-brand-600 transition-colors">Sign In</Link>
          </nav>

          <div className="hidden md:flex items-center gap-4">
            <Link href="/auth?signup=true" className="inline-flex h-10 px-6 items-center justify-center rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-medium shadow-md shadow-brand-600/10 hover:shadow-brand-600/20 active:scale-95 transition-all text-sm">
              Get Started Free
            </Link>
          </div>

          <button 
            className="md:hidden p-2 text-slate-600 hover:text-slate-900"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-b border-slate-200/80 bg-white/95 px-4 py-4 space-y-3 shadow-lg flex flex-col">
            <a href="#features" onClick={() => setMobileMenuOpen(false)} className="px-3 py-2 rounded-lg hover:bg-slate-50 text-slate-700 font-medium">Features</a>
            <a href="#pricing" onClick={() => setMobileMenuOpen(false)} className="px-3 py-2 rounded-lg hover:bg-slate-50 text-slate-700 font-medium">Pricing</a>
            <a href="#faqs" onClick={() => setMobileMenuOpen(false)} className="px-3 py-2 rounded-lg hover:bg-slate-50 text-slate-700 font-medium">FAQ</a>
            <hr className="border-slate-100" />
            <Link href="/auth" className="px-3 py-2 rounded-lg hover:bg-slate-50 text-slate-700 font-medium">Sign In</Link>
            <Link href="/auth?signup=true" className="w-full inline-flex h-11 items-center justify-center rounded-xl bg-brand-600 text-white font-medium text-sm">
              Get Started Free
            </Link>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-20 pb-24 lg:pt-28 lg:pb-32 bg-gradient-to-b from-brand-50/70 via-white to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-brand-100/80 text-brand-700 text-xs font-semibold tracking-wide border border-brand-200">
                <Sparkles className="w-3.5 h-3.5" /> Next-Gen Clinical Education Platform
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-slate-900 leading-tight font-sans">
                Create Professional <br className="hidden sm:inline" />
                <span className="bg-gradient-to-r from-brand-600 to-brand-500 bg-clip-text text-transparent">
                  Nursing Care Plans
                </span> in Minutes
              </h1>
              <p className="text-lg text-slate-600 max-w-2xl mx-auto lg:mx-0 font-sans">
                Digital care plans, clinical logbooks, instructor feedback, and nursing documentation in one unified, HIPAA-compliant platform.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                <Link href="/auth?signup=true" className="w-full sm:w-auto inline-flex h-12 px-8 items-center justify-center rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold shadow-lg shadow-brand-600/20 hover:shadow-brand-600/30 active:scale-98 transition-all gap-2">
                  Start Free Trial <ArrowRight className="w-4 h-4" />
                </Link>
                <a href="#pricing" className="w-full sm:w-auto inline-flex h-12 px-8 items-center justify-center rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-semibold border border-slate-200 transition-all">
                  Book Demo
                </a>
              </div>
            </div>

            {/* Interactive Preview Widget */}
            <div className="lg:col-span-5 relative">
              <div className="absolute inset-0 bg-gradient-to-r from-brand-300 to-cyan-300 blur-2xl opacity-20 -z-10 rounded-full"></div>
              <div className="glass-panel border border-slate-200/80 shadow-2xl rounded-2xl overflow-hidden p-6 space-y-6 animate-slide-up">
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-full bg-rose-500"></span>
                    <span className="w-3.5 h-3.5 rounded-full bg-amber-500"></span>
                    <span className="w-3.5 h-3.5 rounded-full bg-emerald-500"></span>
                  </div>
                  <span className="text-xs font-semibold text-slate-400 bg-slate-100 px-2.5 py-1 rounded-full">Interactive Preview</span>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-brand-50 rounded-lg text-brand-600">
                      <Activity className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs text-slate-400 font-medium">Patient Initials (HIPAA)</div>
                      <div className="text-sm font-semibold text-slate-800">M. K. — Age 62 (Post-op Day 1)</div>
                    </div>
                  </div>

                  <div className="p-3 bg-brand-50/50 rounded-xl border border-brand-100/50 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-brand-700 flex items-center gap-1">
                        <Sparkles className="w-3 h-3" /> AI Diagnosis Suggestion
                      </span>
                      <span className="text-[10px] bg-brand-200/50 text-brand-800 px-1.5 py-0.5 rounded font-mono font-bold">NANDA 00132</span>
                    </div>
                    <p className="text-xs text-slate-600 font-medium">
                      <strong>Acute Pain</strong> related to biological/physical injury agent secondary to abdominal surgery.
                    </p>
                  </div>

                  <div className="space-y-2.5">
                    <div className="text-xs font-bold text-slate-600">SMART Outcome Goal:</div>
                    <div className="flex gap-2">
                      <div className="w-1.5 bg-emerald-500 rounded-full"></div>
                      <div className="text-xs text-slate-600">
                        Patient will verbalize a pain score reduction to <strong>3/10 or lower</strong> within <strong>2 hours</strong> of analgesic administration.
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between text-xs text-slate-400 border-t border-slate-100">
                    <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> Auto-saved 10s ago</span>
                    <span className="text-brand-600 font-semibold hover:underline cursor-pointer">View Full Demo</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof Stats */}
      <section className="bg-slate-900 text-white py-12 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl sm:text-4xl font-extrabold text-brand-400">45,000+</div>
              <div className="text-sm text-slate-400 mt-1">Active Students</div>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-extrabold text-brand-400">220+</div>
              <div className="text-sm text-slate-400 mt-1">Nursing Colleges</div>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-extrabold text-brand-400">1.2M+</div>
              <div className="text-sm text-slate-400 mt-1">Care Plans Created</div>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-extrabold text-brand-400">98.4%</div>
              <div className="text-sm text-slate-400 mt-1">Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-brand-600">Standardizing Nursing Education</h2>
            <p className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 font-sans">
              Smart tools built specifically for clinical training
            </p>
            <p className="text-slate-500 font-sans">
              From NANDA library integration to AI diagnostics support, NursePlan Pro maps exactly to standard nursing processes.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="p-6 rounded-2xl border border-slate-100 hover:shadow-xl hover:border-brand-100 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">Smart Care Plan Builder</h3>
              <p className="text-sm text-slate-500">
                A structured, 6-step guided wizard that leads students from initial subjective and objective assessments through evaluation.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-100 hover:shadow-xl hover:border-brand-100 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                <Clock className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">Clinical Logbook</h3>
              <p className="text-sm text-slate-500">
                Easy procedure logging (IV, Catheter, Meds) with clinical supervisor signatures and instructor approval loops.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-100 hover:shadow-xl hover:border-brand-100 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                <BookOpen className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">Searchable NANDA Library</h3>
              <p className="text-sm text-slate-500">
                A fully searchable catalog containing definition, related factors, risk indicators, and pre-mapped goals.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-100 hover:shadow-xl hover:border-brand-100 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">AI Diagnosis & Review</h3>
              <p className="text-sm text-slate-500">
                Underlying audit engine reviews goals for SMART criteria compliance and identifies missing documentation sections.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-100 hover:shadow-xl hover:border-brand-100 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">Instructor Feedback Portal</h3>
              <p className="text-sm text-slate-500">
                Enables inline commenting, feedback notes, grade adjustments out of 50, and clinical logbook signoffs.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-100 hover:shadow-xl hover:border-brand-100 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">PDF Export & Integration</h3>
              <p className="text-sm text-slate-500">
                Instantly export beautifully formatted care plans ready for printer, binder review, or canvas LMS submission.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-brand-600">Loved by Students & Faculty</h2>
            <p className="text-3xl font-bold text-slate-900 font-sans">What our community is saying</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16">
            {testimonials.map((t, idx) => (
              <div key={idx} className="bg-white p-8 rounded-2xl border border-slate-200/60 shadow-sm flex flex-col justify-between">
                <p className="text-slate-600 italic text-sm">"{t.content}"</p>
                <div className="flex items-center gap-3 mt-6 pt-6 border-t border-slate-100">
                  <div className="w-10 h-10 rounded-full bg-brand-100 text-brand-700 font-bold flex items-center justify-center text-sm">
                    {t.image}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">{t.name}</h4>
                    <p className="text-xs text-slate-400">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-brand-600">Flexible Pricing Plans</h2>
            <p className="text-3xl font-bold text-slate-900 font-sans">Affordable plans for individual students or full departments</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16 max-w-5xl mx-auto">
            {/* Student Plan */}
            <div className="border border-slate-200 rounded-3xl p-8 flex flex-col justify-between hover:shadow-lg transition-all relative">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-bold text-slate-800">Student Plan</h3>
                  <p className="text-xs text-slate-400 mt-1">Perfect for individual clinical training</p>
                </div>
                <div className="flex items-baseline">
                  <span className="text-4xl font-extrabold text-slate-800">$9</span>
                  <span className="text-sm text-slate-400 font-medium">/month</span>
                </div>
                <ul className="space-y-3.5 text-sm text-slate-600">
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> Unlimited Patients & Care Plans
                  </li>
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> Full NANDA Diagnosis Library
                  </li>
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> AI Suggestions & Quality Audits
                  </li>
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> PDF Export & Procedure Logbook
                  </li>
                </ul>
              </div>
              <Link href="/auth?signup=true&plan=student" className="mt-8 w-full inline-flex h-11 items-center justify-center rounded-xl border border-brand-600 text-brand-600 hover:bg-brand-50 font-semibold transition-all">
                Start Free Trial
              </Link>
            </div>

            {/* School Plan */}
            <div className="border-2 border-brand-600 rounded-3xl p-8 flex flex-col justify-between bg-brand-50/20 shadow-xl relative">
              <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-brand-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                Most Popular
              </div>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-bold text-slate-800">School Plan</h3>
                  <p className="text-xs text-slate-400 mt-1">For full cohorts and faculty cohorts</p>
                </div>
                <div className="flex items-baseline">
                  <span className="text-4xl font-extrabold text-slate-800">$299</span>
                  <span className="text-sm text-slate-400 font-medium">/month</span>
                </div>
                <ul className="space-y-3.5 text-sm text-slate-600">
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> Up to 150 Student Accounts
                  </li>
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> Unlimited Instructor Accounts
                  </li>
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> Digital Rubrics & Grading Suite
                  </li>
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> Competency Analytics Dashboards
                  </li>
                </ul>
              </div>
              <Link href="/auth?signup=true&role=school_admin" className="mt-8 w-full inline-flex h-11 items-center justify-center rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold transition-all shadow-md shadow-brand-600/10">
                Sign Up Institution
              </Link>
            </div>

            {/* Enterprise Plan */}
            <div className="border border-slate-200 rounded-3xl p-8 flex flex-col justify-between hover:shadow-lg transition-all relative">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-bold text-slate-800">Enterprise Plan</h3>
                  <p className="text-xs text-slate-400 mt-1">For multi-campus universities & systems</p>
                </div>
                <div className="flex items-baseline">
                  <span className="text-3xl font-extrabold text-slate-800">Custom</span>
                </div>
                <ul className="space-y-3.5 text-sm text-slate-600">
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> Unlimited Users & Schools
                  </li>
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> Canvas / Blackboard LMS Integration
                  </li>
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> Dedicated Success Manager
                  </li>
                  <li className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0" /> Custom Domain & Branding
                  </li>
                </ul>
              </div>
              <button className="mt-8 w-full inline-flex h-11 items-center justify-center rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold transition-all">
                Contact Sales
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faqs" className="py-24 bg-slate-50 border-t border-slate-200/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-brand-600">Frequently Asked Questions</h2>
            <p className="text-3xl font-bold text-slate-900 font-sans">Frequently Asked Questions</p>
          </div>

          <div className="mt-12 space-y-4">
            {FAQs.map((faq, idx) => (
              <div key={idx} className="bg-white rounded-xl border border-slate-200/60 overflow-hidden shadow-sm">
                <button
                  className="w-full px-6 py-4 flex items-center justify-between text-left font-bold text-slate-800 hover:bg-slate-50/50"
                  onClick={() => setFaqOpen(faqOpen === idx ? null : idx)}
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${faqOpen === idx ? 'rotate-180' : ''}`} />
                </button>
                {faqOpen === idx && (
                  <div className="px-6 pb-5 text-sm text-slate-500 border-t border-slate-100 pt-3 leading-relaxed">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Conversion Banner */}
      <section className="bg-gradient-to-r from-brand-700 to-brand-500 text-white py-16">
        <div className="max-w-5xl mx-auto px-4 text-center space-y-6">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">Ready to streamline your care planning?</h2>
          <p className="text-brand-100 max-w-2xl mx-auto">
            Standardize your clinical logbooks and build care plans in minutes with digital instructor oversight.
          </p>
          <div className="pt-2">
            <Link href="/auth?signup=true" className="inline-flex h-12 px-8 items-center justify-center rounded-xl bg-white text-brand-700 hover:bg-slate-100 font-bold shadow-lg transition-all active:scale-95">
              Start Free Trial Now
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-16 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="space-y-4 col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 text-white">
              <Stethoscope className="w-6 h-6 text-brand-400" />
              <span className="text-lg font-bold tracking-tight">NursePlan Pro</span>
            </div>
            <p className="text-xs leading-relaxed max-w-xs">
              SaaS application enabling digital clinical care plans, logs, and rubric-based evaluations for modern nursing schools.
            </p>
          </div>
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">Product</h4>
            <ul className="space-y-2.5 text-sm">
              <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
              <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
              <li><a href="#faqs" className="hover:text-white transition-colors">FAQs</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">Legal</h4>
            <ul className="space-y-2.5 text-sm">
              <li><Link href="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms" className="hover:text-white transition-colors">Terms of Service</Link></li>
              <li><a href="#" className="hover:text-white transition-colors">HIPAA Compliance</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">Contact</h4>
            <ul className="space-y-2.5 text-sm">
              <li>support@nurseplanpro.com</li>
              <li>+1 (800) 555-NURSE</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 mt-8 border-t border-slate-800/80 text-xs flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 NursePlan Pro Inc. All rights reserved.</p>
          <p className="flex items-center gap-1"><ShieldCheck className="w-4 h-4 text-emerald-500" /> HIPAA Secure & Encryption Standard</p>
        </div>
      </footer>
    </div>
  );
}
