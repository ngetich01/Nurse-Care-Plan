"use client";

import Link from "next/link";
import { Stethoscope, ArrowLeft } from "lucide-react";

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-3xl mx-auto bg-white rounded-3xl border border-slate-200/60 shadow-xl p-8 md:p-12 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-6">
          <div className="flex items-center gap-2">
            <Stethoscope className="w-6 h-6 text-brand-650" />
            <span className="text-lg font-bold tracking-tight">NursePlan Pro</span>
          </div>
          <Link href="/" className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1 font-semibold">
            <ArrowLeft className="w-3.5 h-3.5" /> Back Home
          </Link>
        </div>

        <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Privacy Policy</h1>
        <p className="text-xs text-slate-400">Last updated: June 13, 2026</p>

        <div className="space-y-4 text-sm text-slate-600 leading-relaxed">
          <p>
            At NursePlan Pro, we prioritize security, patient confidentiality, and compliance with modern healthcare regulations, including the Health Insurance Portability and Accountability Act (HIPAA) and the General Data Protection Regulation (GDPR).
          </p>

          <h3 className="font-bold text-slate-800 text-base">1. HIPAA Compliance & Data Minimization</h3>
          <p>
            To protect patient confidentiality, students are prohibited from entering personally identifiable information (PII) or protected health information (PHI) of patients. NursePlan Pro enforces the use of initials only. No real social security numbers, full names, addresses, or phone numbers of clinical patients should ever be recorded on this platform.
          </p>

          <h3 className="font-bold text-slate-800 text-base">2. Information We Collect</h3>
          <p>
            We collect the registration details of students, instructors, and schools (such as full names, email addresses, enrollment numbers, employee IDs, and school names) to run the account authentication system.
          </p>

          <h3 className="font-bold text-slate-800 text-base">3. Audit Trails & Logs</h3>
          <p>
            System-level audit trails record user login, creation, modification, and deletion events, including timestamp, IP address, and user metadata. These security logs are stored to prevent unauthorized access and facilitate regulatory compliance reports.
          </p>
        </div>
      </div>
    </div>
  );
}
