"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { 
  Stethoscope, 
  Activity, 
  Sparkles, 
  ArrowLeft, 
  ArrowRight, 
  Save, 
  Check, 
  AlertTriangle, 
  Info,
  Plus, 
  Trash2,
  FileText,
  Printer,
  FileDown
} from "lucide-react";

function CarePlanBuilderContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const planId = searchParams.get("id");

  // Flow State
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [saveStatus, setSaveStatus] = useState("Saved");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Patients (to select if creating new plan)
  const [patients, setPatients] = useState<any[]>([]);
  const [selectedPatientId, setSelectedPatientId] = useState("");
  const [patientDetails, setPatientDetails] = useState<any>(null);

  // Form Fields
  const [title, setTitle] = useState("Care Plan Draft");
  
  // Step 1: Assessment
  const [subjectiveData, setSubjectiveData] = useState("");
  const [objectiveData, setObjectiveData] = useState("");

  // Step 2: Diagnosis
  const [nursingDiagnosis, setNursingDiagnosis] = useState<any[]>([]);
  const [searchDiagQuery, setSearchDiagQuery] = useState("");
  const [diagLibrary, setDiagLibrary] = useState<any[]>([]);
  const [aiDiagSuggestions, setAiDiagSuggestions] = useState<any[]>([]);

  // Step 3: Goals
  const [shortTermGoals, setShortTermGoals] = useState<any[]>([]);
  const [longTermGoals, setLongTermGoals] = useState<any[]>([]);
  const [newStGoalText, setNewStGoalText] = useState("");
  const [newLtGoalText, setNewLtGoalText] = useState("");

  // Step 4: Interventions
  const [interventions, setInterventions] = useState<any[]>([]);
  const [newIntDesc, setNewIntDesc] = useState("");
  const [newIntPriority, setNewIntPriority] = useState("medium");
  const [newIntRationale, setNewIntRationale] = useState("");

  // Step 5: Implementation
  const [implementationNotes, setImplementationNotes] = useState("");

  // Step 6: Evaluation
  const [evaluationStatus, setEvaluationStatus] = useState<"met" | "partially_met" | "not_met" | "">("");
  const [evaluationNotes, setEvaluationNotes] = useState("");

  // AI Auditor Report state
  const [aiReport, setAiReport] = useState<any>(null);
  const [auditing, setAuditing] = useState(false);

  const baseUrl = "http://localhost:5000/api";

  // Initial loads
  useEffect(() => {
    const token = localStorage.getItem("nurseplan_token");
    if (!token) {
      router.push("/auth");
      return;
    }
    fetchPatients(token);
    fetchDiagnoses();

    if (planId) {
      fetchCarePlanDetails(token, planId);
    }
  }, [planId]);

  // Handle auto-save trigger on input shifts
  useEffect(() => {
    if (!planId) return;
    const delayDebounceFn = setTimeout(() => {
      autoSaveDraft();
    }, 2000); // Debounce saves by 2 seconds

    return () => clearTimeout(delayDebounceFn);
  }, [
    title, subjectiveData, objectiveData, nursingDiagnosis, 
    shortTermGoals, longTermGoals, interventions, 
    implementationNotes, evaluationStatus, evaluationNotes
  ]);

  const fetchPatients = async (token: string) => {
    try {
      const res = await fetch(`${baseUrl}/patients`, {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setPatients(data);
        if (data.length > 0 && !planId) {
          setSelectedPatientId(data[0].id);
          setPatientDetails(data[0]);
        }
      }
    } catch (e) {
      // Local Mock fallbacks
      const mockPats = [
        { id: "pat-1", initials: "K. R.", age: 45, gender: "Male", ward: "Med-Surg", bed_number: "204B", medical_diagnosis: "Pneumonia", history_of_present_illness: "Patient admitted with shortness of breath, fever, productive cough.", allergies: "NKA", current_medications: "Albuterol PRN, Azithromycin IV" },
        { id: "pat-2", initials: "S. T.", age: 67, gender: "Female", ward: "Cardiology", bed_number: "102A", medical_diagnosis: "Congestive Heart Failure" }
      ];
      setPatients(mockPats);
      if (!planId) {
        setSelectedPatientId(mockPats[0].id);
        setPatientDetails(mockPats[0]);
      }
    }
  };

  const fetchDiagnoses = async () => {
    try {
      const res = await fetch(`${baseUrl}/diagnoses`);
      if (res.ok) setDiagLibrary(await res.json());
    } catch (e) {
      setDiagLibrary([
        { id: "diag-001", code: "00132", name: "Acute Pain", category: "Neurological" },
        { id: "diag-002", code: "00004", name: "Risk for Infection", category: "Renal" },
        { id: "diag-003", code: "00031", name: "Ineffective Airway Clearance", category: "Respiratory" },
        { id: "diag-004", code: "00085", name: "Impaired Physical Mobility", category: "Musculoskeletal" },
        { id: "diag-005", code: "00146", name: "Anxiety", category: "Mental Health" }
      ]);
    }
  };

  const fetchCarePlanDetails = async (token: string, id: string) => {
    try {
      const res = await fetch(`${baseUrl}/careplans/${id}`, {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!res.ok) throw new Error("Plan not found");
      const data = await res.json();
      const cp = data.carePlan;

      setTitle(cp.title);
      setSubjectiveData(cp.subjective_data || "");
      setObjectiveData(cp.objective_data || "");
      setNursingDiagnosis(JSON.parse(cp.nursing_diagnosis || "[]"));
      setShortTermGoals(JSON.parse(cp.short_term_goals || "[]"));
      setLongTermGoals(JSON.parse(cp.long_term_goals || "[]"));
      setInterventions(JSON.parse(cp.interventions || "[]"));
      setImplementationNotes(cp.implementation_notes || "");
      setEvaluationStatus(cp.evaluation_status || "");
      setEvaluationNotes(cp.evaluation_notes || "");
      setSelectedPatientId(cp.patient_id);
      
      setPatientDetails({
        initials: cp.patient_initials,
        age: cp.patient_age,
        gender: cp.patient_gender,
        ward: cp.patient_ward,
        bed_number: cp.patient_bed,
        admission_date: cp.patient_admission_date,
        medical_diagnosis: cp.patient_medical_diagnosis,
        history_of_present_illness: cp.history_of_present_illness,
        allergies: cp.allergies,
        current_medications: cp.current_medications
      });
    } catch (e) {
      console.warn("Failed fetching via API, loading offline plan state");
    }
  };

  const handlePatientSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const id = e.target.value;
    setSelectedPatientId(id);
    const pat = patients.find(p => p.id === id);
    if (pat) setPatientDetails(pat);
  };

  // Create plan initially
  const handleInitializePlan = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/careplans`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          patientId: selectedPatientId,
          title
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      router.push(`/builder?id=${data.id}`);
      setStep(1);
    } catch (err) {
      // Offline mock creation
      const mockId = `mock-${Date.now()}`;
      router.push(`/builder?id=${mockId}`);
      setStep(1);
    } finally {
      setLoading(false);
    }
  };

  // Auto save draft API call
  const autoSaveDraft = async () => {
    if (!planId || planId.startsWith("mock")) {
      setSaveStatus("Saved locally");
      return;
    }
    setSaveStatus("Saving...");
    try {
      const token = localStorage.getItem("nurseplan_token");
      await fetch(`${baseUrl}/careplans/${planId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          title,
          subjectiveData,
          objectiveData,
          nursingDiagnosis: JSON.stringify(nursingDiagnosis),
          shortTermGoals: JSON.stringify(shortTermGoals),
          longTermGoals: JSON.stringify(longTermGoals),
          interventions: JSON.stringify(interventions),
          implementationNotes,
          evaluationStatus: evaluationStatus || undefined,
          evaluationNotes
        })
      });
      setSaveStatus("Saved");
    } catch (e) {
      setSaveStatus("Save failed (Offline)");
    }
  };

  // Submit plan
  const handleSubmitPlan = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/careplans/${planId}/submit`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!res.ok) throw new Error("Submission failed");
      setSuccess("Your nursing care plan assignment has been submitted to your instructor!");
      setTimeout(() => router.push("/student"), 2000);
    } catch (e) {
      setSuccess("Care plan submitted successfully (Offline Mode)");
      setTimeout(() => router.push("/student"), 2000);
    } finally {
      setLoading(false);
    }
  };

  // AI Suggestion: Diagnoses
  const triggerAiDiagnoses = async () => {
    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/ai/diagnoses`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ subjectiveData, objectiveData })
      });
      const data = await res.json();
      setAiDiagSuggestions(data.suggestions || []);
    } catch (e) {
      // Offline mockup rule-matcher
      const text = `${subjectiveData} ${objectiveData}`.toLowerCase();
      const mocks = [];
      if (text.includes("breath") || text.includes("cough")) {
        mocks.push({ code: "00031", name: "Ineffective Airway Clearance", matchReason: "Assessment indicates respiratory compromises." });
      }
      if (text.includes("pain") || text.includes("hurt")) {
        mocks.push({ code: "00132", name: "Acute Pain", matchReason: "Client reports localized physical discomfort." });
      }
      if (mocks.length === 0) {
        mocks.push({ code: "00004", name: "Risk for Infection", matchReason: "General preventive training suggested." });
      }
      setAiDiagSuggestions(mocks);
    }
  };

  // AI Suggestion: Goals
  const triggerAiGoals = async (diagName: string) => {
    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/ai/goals`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ diagnosisName: diagName })
      });
      const data = await res.json();
      
      // Auto-populate generated goals
      if (data.goals) {
        const st = data.goals.filter((g: any) => g.type === "short-term").map((g: any) => g.text);
        const lt = data.goals.filter((g: any) => g.type === "long-term").map((g: any) => g.text);
        setShortTermGoals([...shortTermGoals, ...st]);
        setLongTermGoals([...longTermGoals, ...lt]);
      }
    } catch (e) {
      // Fallback goals
      setShortTermGoals([...shortTermGoals, `Patient will stabilize vitals within 4 hours.`]);
      setLongTermGoals([...longTermGoals, `Patient will demonstrate self-care before discharge.`]);
    }
  };

  // AI Suggestion: Interventions
  const triggerAiInterventions = async (diagName: string) => {
    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/ai/interventions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ diagnosisName: diagName })
      });
      const data = await res.json();
      if (data.interventions) {
        setInterventions([...interventions, ...data.interventions]);
      }
    } catch (e) {
      setInterventions([...interventions, {
        description: `Monitor patient parameters closely.`,
        priority: "high",
        rationale: `Continuous assessment ensures timely clinical feedback.`
      }]);
    }
  };

  // AI Care Plan Reviewer Auditing
  const runQualityAudit = async () => {
    setAuditing(true);
    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/ai/review`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          subjectiveData,
          objectiveData,
          nursingDiagnosis: JSON.stringify(nursingDiagnosis),
          shortTermGoals: JSON.stringify(shortTermGoals),
          longTermGoals: JSON.stringify(longTermGoals),
          interventions: JSON.stringify(interventions)
        })
      });
      const data = await res.json();
      setAiReport(data);
    } catch (e) {
      // Offline fallback report
      setAiReport({
        score: 90,
        status: "excellent",
        issues: [
          { type: "info", section: "Assessment", message: "Assessments are solid. Clean parameters detected.", fix: "Good job!" }
        ]
      });
    } finally {
      setAuditing(false);
    }
  };

  const addDiagnosis = (diag: any) => {
    if (!nursingDiagnosis.some(d => d.code === diag.code)) {
      setNursingDiagnosis([...nursingDiagnosis, diag]);
    }
  };

  const removeDiagnosis = (code: string) => {
    setNursingDiagnosis(nursingDiagnosis.filter(d => d.code !== code));
  };

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-50 font-sans">
      
      {/* Header bar */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/student" className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="text-lg font-bold text-slate-800 focus:outline-none focus:border-b focus:border-slate-300 w-64 bg-transparent"
              />
              <span className="text-xs bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full capitalize">{saveStatus}</span>
            </div>
            {patientDetails && (
              <p className="text-xs text-slate-400 mt-0.5">
                Patient initials: {patientDetails.initials} • Med Diagnosis: {patientDetails.medical_diagnosis}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => window.print()}
            className="inline-flex h-9 px-3 items-center justify-center rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold shadow-sm gap-1.5"
          >
            <Printer className="w-4 h-4" /> Print View
          </button>
          <button
            onClick={runQualityAudit}
            className="inline-flex h-9 px-3.5 items-center justify-center rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-700 text-xs font-bold border border-teal-200 gap-1.5"
          >
            <Sparkles className="w-4 h-4 text-teal-600" /> AI Audit Review
          </button>
          {step === 6 && (
            <button
              onClick={handleSubmitPlan}
              disabled={loading}
              className="inline-flex h-9 px-4 items-center justify-center rounded-lg bg-brand-600 hover:bg-brand-700 disabled:bg-slate-300 text-white text-xs font-bold shadow-md transition-all"
            >
              {loading ? "Submitting..." : "Submit Assignment"}
            </button>
          )}
        </div>
      </header>

      {/* Main Builder Grid */}
      <div className="flex-1 grid lg:grid-cols-12 gap-8 p-6 md:p-8 max-w-7xl mx-auto w-full">
        
        {/* Left Hand: The Step Form Wizard */}
        <div className="lg:col-span-8 bg-white border border-slate-200/60 shadow-lg rounded-3xl p-6 md:p-8 flex flex-col justify-between space-y-8 min-h-[70vh]">
          
          {/* Step indicator header */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-5">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Step {step} of 6</span>
              <h2 className="text-xl font-bold text-slate-800 mt-0.5">
                {step === 1 && "Step 1: Patient Assessment"}
                {step === 2 && "Step 2: Nursing Diagnosis"}
                {step === 3 && "Step 3: SMART Goals & Outcomes"}
                {step === 4 && "Step 4: Nursing Interventions"}
                {step === 5 && "Step 5: Intervention Implementation"}
                {step === 6 && "Step 6: Clinical Evaluation"}
              </h2>
            </div>

            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <button
                  key={i}
                  onClick={() => planId && setStep(i)}
                  className={`w-7 h-7 rounded-full text-xs font-bold flex items-center justify-center transition-all ${
                    step === i ? "bg-brand-600 text-white shadow-md shadow-brand-500/20" :
                    step > i ? "bg-brand-100 text-brand-700" :
                    "bg-slate-100 text-slate-400 cursor-not-allowed"
                  }`}
                  disabled={!planId}
                >
                  {i}
                </button>
              ))}
            </div>
          </div>

          {/* Setup screen if no planId exists */}
          {!planId ? (
            <div className="flex-1 flex flex-col justify-center items-center text-center p-8 space-y-6">
              <div className="w-16 h-16 rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center">
                <FileText className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-bold text-slate-800">Initialize Care Plan</h3>
                <p className="text-sm text-slate-500 max-w-sm">
                  Select a clinical patient record to initialize the care plan documentation workflow.
                </p>
              </div>

              {patients.length === 0 ? (
                <div className="p-4 bg-rose-50 border border-rose-100 text-rose-700 text-xs rounded-xl">
                  Please create a Patient Record in your dashboard before starting a care plan.
                </div>
              ) : (
                <div className="w-full max-w-xs space-y-4">
                  <div className="space-y-1 text-left">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Select Patient</label>
                    <select
                      value={selectedPatientId}
                      onChange={handlePatientSelect}
                      className="w-full h-11 px-3 border border-slate-200 rounded-xl text-sm bg-white"
                    >
                      {patients.map(p => (
                        <option key={p.id} value={p.id}>
                          {p.initials} — {p.medical_diagnosis}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="space-y-1 text-left">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Care Plan Title</label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full h-11 px-3 border border-slate-200 rounded-xl text-sm"
                    />
                  </div>

                  <button
                    onClick={handleInitializePlan}
                    disabled={loading}
                    className="w-full h-11 bg-brand-600 hover:bg-brand-700 text-white font-bold rounded-xl text-sm transition-all"
                  >
                    Start Documentation Process
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Active Steps Render */
            <div className="flex-1 space-y-6">
              
              {/* STEP 1: Assessment */}
              {step === 1 && (
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                      Subjective Data <Info className="w-3.5 h-3.5 text-slate-400" />
                    </label>
                    <p className="text-[10px] text-slate-400 leading-normal">
                      Patient complaints, historical symptoms, family accounts, verbal pain cues, scale verbalizations.
                    </p>
                    <textarea
                      rows={6}
                      placeholder="e.g. Patient states: 'I can't catch my breath when I sit up' and reports chest tightness. Pain rated 4/10 upon deep inspiration."
                      value={subjectiveData}
                      onChange={(e) => setSubjectiveData(e.target.value)}
                      className="w-full p-4 border border-slate-200 rounded-2xl text-sm leading-relaxed"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 block">Objective Data</label>
                    <p className="text-[10px] text-slate-400 leading-normal">
                      Observable vital signs, physical inspection notes, auscultations, laboratory outputs, lab reports.
                    </p>
                    <textarea
                      rows={6}
                      placeholder="e.g. BP 138/85, HR 92, RR 24, Temp 100.8 F, SpO2 91% on room air. Auscultation reveals crackles in lower lobes. Lab: WBC 14.5."
                      value={objectiveData}
                      onChange={(e) => setObjectiveData(e.target.value)}
                      className="w-full p-4 border border-slate-200 rounded-2xl text-sm leading-relaxed"
                    />
                  </div>
                </div>
              )}

              {/* STEP 2: Diagnoses Selection */}
              {step === 2 && (
                <div className="space-y-6">
                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-700 block">Select Active Nursing Diagnoses (NANDA)</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Search diagnoses (e.g. Pain, Mobility, Airway)..."
                        value={searchDiagQuery}
                        onChange={(e) => setSearchDiagQuery(e.target.value)}
                        className="flex-1 h-10 px-3 border border-slate-200 rounded-xl text-sm"
                      />
                      <button
                        onClick={triggerAiDiagnoses}
                        className="h-10 px-4 bg-brand-50 hover:bg-brand-100 text-brand-700 border border-brand-200 text-xs font-bold rounded-xl flex items-center gap-1"
                      >
                        <Sparkles className="w-4 h-4 text-brand-600" /> AI Suggestions
                      </button>
                    </div>
                  </div>

                  {/* AI Suggestions panel */}
                  {aiDiagSuggestions.length > 0 && (
                    <div className="p-4 bg-brand-50/50 border border-brand-200/50 rounded-2xl space-y-2">
                      <h4 className="text-[10px] font-bold text-brand-700 uppercase tracking-wide flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-brand-600" /> AI Diagnoses Suggestions
                      </h4>
                      <div className="flex flex-col gap-2">
                        {aiDiagSuggestions.map(s => (
                          <div key={s.code} className="bg-white p-3 rounded-xl border border-brand-100 flex justify-between items-start text-xs">
                            <div className="space-y-1">
                              <strong>{s.name} (Code {s.code})</strong>
                              <p className="text-slate-500 text-[10px]">{s.matchReason}</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => addDiagnosis(s)}
                              className="text-[10px] bg-brand-600 hover:bg-brand-700 text-white font-bold px-2.5 py-1 rounded"
                            >
                              Attach
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Selected Diagnoses */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wide">Selected Diagnoses</h4>
                    {nursingDiagnosis.length === 0 ? (
                      <p className="text-xs text-slate-400 italic">No diagnoses attached yet. Search library or run AI helper.</p>
                    ) : (
                      <div className="flex flex-wrap gap-2">
                        {nursingDiagnosis.map(d => (
                          <div key={d.code} className="bg-slate-100 text-slate-700 text-xs rounded-full pl-3 pr-2 py-1 flex items-center gap-2 font-medium">
                            <span>{d.name} ({d.code})</span>
                            <button
                              type="button"
                              onClick={() => removeDiagnosis(d.code)}
                              className="w-4 h-4 bg-slate-300 hover:bg-slate-400 rounded-full flex items-center justify-center text-[10px] text-slate-600"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Library Results list */}
                  <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar border border-slate-100 rounded-2xl">
                    {diagLibrary
                      .filter(d => d.name.toLowerCase().includes(searchDiagQuery.toLowerCase()))
                      .map(d => (
                        <div key={d.id} className="p-3 hover:bg-slate-50 flex justify-between items-center text-xs border-b border-slate-50">
                          <div>
                            <span className="font-bold text-slate-700">{d.name}</span>
                            <span className="text-[10px] text-slate-400 ml-2 font-mono">Code {d.code}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => addDiagnosis(d)}
                            className="inline-flex h-7 px-2.5 items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded"
                          >
                            Add
                          </button>
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {/* STEP 3: Goals and Outcomes */}
              {step === 3 && (
                <div className="space-y-6">
                  
                  {/* AI Goal assist widget */}
                  {nursingDiagnosis.length > 0 && (
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/50 flex items-center justify-between gap-4">
                      <div className="text-xs text-slate-500">
                        Suggest SMART goals for diagnosis: <strong>{nursingDiagnosis[0].name}</strong>
                      </div>
                      <button
                        onClick={() => triggerAiGoals(nursingDiagnosis[0].name)}
                        className="h-8 px-3.5 bg-brand-600 hover:bg-brand-700 text-white font-bold rounded-lg text-[10px] flex items-center gap-1"
                      >
                        <Sparkles className="w-3.5 h-3.5" /> Generate SMART Goals
                      </button>
                    </div>
                  )}

                  {/* Short-Term Goals */}
                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-700 block">Short-Term Goals (Shift level: 1-12 hours)</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="e.g. Patient will maintain SpO2 above 94% on 2L NC within 4 hours..."
                        value={newStGoalText}
                        onChange={(e) => setNewStGoalText(e.target.value)}
                        className="flex-1 h-10 px-3 border border-slate-200 rounded-xl text-sm"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (newStGoalText) {
                            setShortTermGoals([...shortTermGoals, newStGoalText]);
                            setNewStGoalText("");
                          }
                        }}
                        className="h-10 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs"
                      >
                        Add Goal
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      {shortTermGoals.map((g, idx) => (
                        <div key={idx} className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex justify-between items-center text-xs">
                          <span className="text-slate-700 font-medium">{g}</span>
                          <button
                            type="button"
                            onClick={() => setShortTermGoals(shortTermGoals.filter((_, i) => i !== idx))}
                            className="text-slate-400 hover:text-rose-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Long-Term Goals */}
                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-700 block">Long-Term Goals (Discharge / weekly levels)</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="e.g. Patient will demonstrate correct inhaler usage prior to discharge..."
                        value={newLtGoalText}
                        onChange={(e) => setNewLtGoalText(e.target.value)}
                        className="flex-1 h-10 px-3 border border-slate-200 rounded-xl text-sm"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (newLtGoalText) {
                            setLongTermGoals([...longTermGoals, newLtGoalText]);
                            setNewLtGoalText("");
                          }
                        }}
                        className="h-10 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs"
                      >
                        Add Goal
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      {longTermGoals.map((g, idx) => (
                        <div key={idx} className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex justify-between items-center text-xs">
                          <span className="text-slate-700 font-medium">{g}</span>
                          <button
                            type="button"
                            onClick={() => setLongTermGoals(longTermGoals.filter((_, i) => i !== idx))}
                            className="text-slate-400 hover:text-rose-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 4: Interventions */}
              {step === 4 && (
                <div className="space-y-6">
                  {/* AI helper */}
                  {nursingDiagnosis.length > 0 && (
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/50 flex items-center justify-between gap-4">
                      <div className="text-xs text-slate-500">
                        Suggest interventions for: <strong>{nursingDiagnosis[0].name}</strong>
                      </div>
                      <button
                        onClick={() => triggerAiInterventions(nursingDiagnosis[0].name)}
                        className="h-8 px-3.5 bg-brand-600 hover:bg-brand-700 text-white font-bold rounded-lg text-[10px] flex items-center gap-1"
                      >
                        <Sparkles className="w-3.5 h-3.5" /> Suggest Evidence-Based Actions
                      </button>
                    </div>
                  )}

                  {/* Add Intervention */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-4">
                    <h4 className="text-xs font-bold text-slate-700">Add Custom Intervention</h4>
                    
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wide">Action Description</label>
                      <input
                        type="text"
                        placeholder="e.g. Auscultate lung sounds every 2 hours and monitor respiratory trend."
                        value={newIntDesc}
                        onChange={(e) => setNewIntDesc(e.target.value)}
                        className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wide">Priority</label>
                        <select
                          value={newIntPriority}
                          onChange={(e) => setNewIntPriority(e.target.value)}
                          className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm bg-white"
                        >
                          <option value="high">High Priority</option>
                          <option value="medium">Medium Priority</option>
                          <option value="low">Low Priority</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wide">Scientific Rationale</label>
                        <input
                          type="text"
                          placeholder="Why do this? e.g. Early detection of crackles monitors fluid shifts."
                          value={newIntRationale}
                          onChange={(e) => setNewIntRationale(e.target.value)}
                          className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (newIntDesc && newIntRationale) {
                          setInterventions([...interventions, {
                            description: newIntDesc,
                            priority: newIntPriority,
                            rationale: newIntRationale
                          }]);
                          setNewIntDesc("");
                          setNewIntRationale("");
                        }
                      }}
                      className="h-10 px-4 bg-brand-600 hover:bg-brand-700 text-white font-bold rounded-xl text-xs w-full"
                    >
                      Record Intervention
                    </button>
                  </div>

                  {/* List Interventions */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wide">Recorded Interventions</h4>
                    {interventions.length === 0 ? (
                      <p className="text-xs text-slate-400 italic">No interventions added yet. Complete the form above.</p>
                    ) : (
                      <div className="space-y-3">
                        {interventions.map((item, idx) => (
                          <div key={idx} className="p-4 bg-white rounded-2xl border border-slate-200/60 shadow-sm space-y-2 flex justify-between items-start">
                            <div className="space-y-1 text-xs">
                              <div className="flex items-center gap-2">
                                <span className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase ${
                                  item.priority === 'high' ? 'bg-rose-50 text-rose-700' : 'bg-slate-100 text-slate-700'
                                }`}>
                                  {item.priority} priority
                                </span>
                              </div>
                              <p className="text-slate-800 font-semibold">{item.description}</p>
                              <p className="text-slate-500 text-[10px]"><strong>Rationale:</strong> {item.rationale}</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => setInterventions(interventions.filter((_, i) => i !== idx))}
                              className="text-slate-300 hover:text-rose-500"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* STEP 5: Implementation */}
              {step === 5 && (
                <div className="space-y-3">
                  <label className="text-xs font-bold text-slate-700 block">Record Implementation Notes</label>
                  <p className="text-[10px] text-slate-400 leading-normal">
                    Describe how the patient responded to interventions, exact times administered, clinical complications, or adjustments.
                  </p>
                  <textarea
                    rows={8}
                    placeholder="e.g. Oxygen therapy initialized at 2L NC at 0900. Auscultated lungs at 1000 — crackles still present but respiratory rate declined to 20. Administered ordered Azithromycin IV at 1030 without hypersensitivity signs."
                    value={implementationNotes}
                    onChange={(e) => setImplementationNotes(e.target.value)}
                    className="w-full p-4 border border-slate-200 rounded-2xl text-sm leading-relaxed"
                  />
                </div>
              )}

              {/* STEP 6: Evaluation */}
              {step === 6 && (
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <label className="text-xs font-bold text-slate-700 block">Goal Outcome Status</label>
                    <div className="flex flex-col gap-2">
                      {[
                        { key: "met", label: "Goal Met", desc: "Outcomes fully achieved as planned" },
                        { key: "partially_met", label: "Partially Met", desc: "Some goals achieved, others ongoing" },
                        { key: "not_met", label: "Not Met", desc: "No significant progress, requires path adjustments" }
                      ].map(item => (
                        <button
                          key={item.key}
                          type="button"
                          onClick={() => setEvaluationStatus(item.key as any)}
                          className={`p-4 border rounded-2xl text-left flex justify-between items-center transition-all ${
                            evaluationStatus === item.key 
                              ? "bg-brand-50 border-brand-500 shadow-sm" 
                              : "border-slate-200 hover:bg-slate-50"
                          }`}
                        >
                          <div>
                            <span className="text-sm font-bold text-slate-800 block capitalize">{item.label}</span>
                            <span className="text-[10px] text-slate-400 mt-0.5 block">{item.desc}</span>
                          </div>
                          {evaluationStatus === item.key && <Check className="w-5 h-5 text-brand-600" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 block">Evaluation & Refinement Notes</label>
                    <p className="text-[10px] text-slate-400 leading-normal">
                      Examine why objectives were met/unmet and formulate recommendations (e.g. discontinue care plan, modify times, increase dosage).
                    </p>
                    <textarea
                      rows={6}
                      placeholder="e.g. SpO2 met normal levels (95%) and patient reports chest tightness eased. Recommend continuing monitoring but transitioning care plan to physical mobilization goals."
                      value={evaluationNotes}
                      onChange={(e) => setEvaluationNotes(e.target.value)}
                      className="w-full p-4 border border-slate-200 rounded-2xl text-sm leading-relaxed"
                    />
                  </div>
                </div>
              )}

            </div>
          )}

          {/* Navigation Controls footer */}
          {planId && (
            <div className="border-t border-slate-100 pt-5 flex items-center justify-between">
              <button
                onClick={() => setStep(Math.max(step - 1, 1))}
                disabled={step === 1}
                className="inline-flex h-10 px-5 items-center justify-center rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold shadow-sm disabled:opacity-50"
              >
                Previous Step
              </button>

              <button
                onClick={() => setStep(Math.min(step + 1, 6))}
                disabled={step === 6}
                className="inline-flex h-10 px-5 items-center justify-center rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold shadow-md gap-1"
              >
                Next Step <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Right Hand: Interactive AI Audit Side Panel */}
        <div className="lg:col-span-4 bg-slate-900 text-white rounded-3xl p-6 space-y-6 shadow-2xl relative">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <h3 className="font-bold flex items-center gap-1.5 text-sm">
              <Sparkles className="w-5 h-5 text-brand-400" /> AI Clinical Reviewer
            </h3>
            <button
              onClick={runQualityAudit}
              disabled={auditing || !planId}
              className="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-2 py-1 rounded disabled:opacity-40"
            >
              {auditing ? "Auditing..." : "Audit Now"}
            </button>
          </div>

          {!aiReport ? (
            <div className="text-center py-12 space-y-4">
              <Activity className="w-10 h-10 text-slate-600 mx-auto animate-pulse-subtle" />
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-slate-300">Run Quality Inspection</h4>
                <p className="text-[10px] text-slate-500 max-w-[200px] mx-auto">
                  Click 'Audit Now' to examine your data for clinical completeness and SMART outcomes.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-5 animate-slide-up text-sm">
              {/* Audit score radial simulation */}
              <div className="flex items-center gap-4 bg-slate-850 p-4 rounded-2xl border border-slate-800">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg border-2 ${
                  aiReport.score >= 85 ? 'border-emerald-500 text-emerald-400' :
                  aiReport.score >= 70 ? 'border-amber-500 text-amber-400' :
                  'border-rose-500 text-rose-400'
                }`}>
                  {aiReport.score}
                </div>
                <div>
                  <div className="font-bold capitalize text-xs">Quality Index Score</div>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    {aiReport.score >= 85 ? 'Care plan is detailed and structured.' : 'Review recommended improvements below.'}
                  </p>
                </div>
              </div>

              {/* Critiques list */}
              <div className="space-y-3 overflow-y-auto max-h-[45vh] custom-scrollbar pr-1">
                {aiReport.issues.length === 0 ? (
                  <div className="flex gap-2 p-3 bg-emerald-950/20 text-emerald-400 rounded-xl border border-emerald-900/50 text-xs">
                    <Check className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <div>
                      <strong>No issues detected!</strong>
                      <p className="text-[10px] mt-0.5">Care plan fits all institutional rubrics.</p>
                    </div>
                  </div>
                ) : (
                  aiReport.issues.map((iss: any, index: number) => (
                    <div key={index} className={`p-3.5 rounded-xl border text-xs space-y-2 ${
                      iss.type === 'critical' ? 'bg-rose-950/20 border-rose-900/50 text-rose-300' :
                      iss.type === 'warning' ? 'bg-amber-950/20 border-amber-900/50 text-amber-300' :
                      'bg-slate-850 border-slate-800 text-slate-300'
                    }`}>
                      <div className="flex items-center gap-1.5">
                        <AlertTriangle className={`w-4 h-4 ${iss.type === 'critical' ? 'text-rose-500' : 'text-amber-500'}`} />
                        <span className="font-bold uppercase tracking-wider text-[9px] bg-white/10 px-1.5 py-0.5 rounded">
                          {iss.section}
                        </span>
                      </div>
                      <p className="font-medium">{iss.message}</p>
                      <div className="bg-black/20 p-2 rounded text-[10px] italic leading-relaxed text-slate-300 border border-white/5">
                        <strong>Fix:</strong> {iss.fix}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

      </div>
    </div>

  );
}

export default function CarePlanBuilder() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center bg-slate-50"><div className="w-8 h-8 border-4 border-brand-600 border-t-transparent rounded-full animate-spin"></div></div>}>
      <CarePlanBuilderContent />
    </Suspense>
  );
}
