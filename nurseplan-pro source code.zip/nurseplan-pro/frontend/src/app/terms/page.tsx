"use client";

import Link from "next/link";
import { Stethoscope, ArrowLeft } from "lucide-react";

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-3xl mx-auto bg-white rounded-3xl border border-slate-200/60 shadow-xl p-8 md:p-12 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-6">
          <div className="flex items-center gap-2">
            <Stethoscope className="w-6 h-6 text-brand-650" />
            <span className="text-lg font-bold tracking-tight">NursePlan Pro</span>
          </div>
          <Link href="/" className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1 font-semibold">
            <ArrowLeft className="w-3.5 h-3.5" /> Back Home
          </Link>
        </div>

        <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Terms of Service</h1>
        <p className="text-xs text-slate-400">Last updated: June 13, 2026</p>

        <div className="space-y-4 text-sm text-slate-600 leading-relaxed">
          <p>
            Welcome to NursePlan Pro. By utilizing our platform, you agree to comply with the following Terms of Service.
          </p>

          <h3 className="font-bold text-slate-800 text-base">1. Acceptable Use Policy</h3>
          <p>
            Our care plan builder is intended as an educational scaffold for nursing students and clinical training programs. You agree to use the platform solely for learning and documentation simulation, and not as a replacement for real-time electronic health records (EHR) of active clinical facilities.
          </p>

          <h3 className="font-bold text-slate-800 text-base">2. Security Safeguards</h3>
          <p>
            Users are responsible for keeping login credentials secure. Enforcing Multi-Factor Authentication (MFA) is highly recommended for all users to ensure safety boundaries are maintained.
          </p>
        </div>
      </div>
    </div>
  );
}
