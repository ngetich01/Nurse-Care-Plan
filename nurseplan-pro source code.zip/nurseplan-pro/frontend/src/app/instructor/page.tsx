"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { 
  Stethoscope, 
  Users, 
  FileText, 
  Clock, 
  CheckCircle2, 
  Award, 
  MessageSquare,
  AlertCircle,
  FileEdit,
  GraduationCap,
  LogOut,
  ChevronRight,
  TrendingUp,
  Search
} from "lucide-react";

export default function InstructorDashboard() {
  const router = useRouter();

  // Core stats
  const [user, setUser] = useState<any>(null);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [cohort, setCohort] = useState<any[]>([]);

  // Selection state
  const [selectedSubmission, setSelectedSubmission] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"submissions" | "logs" | "students">("submissions");

  // Grading rubric form values
  const [assessmentScore, setAssessmentScore] = useState(8);
  const [diagnosisScore, setDiagnosisScore] = useState(8);
  const [goalsScore, setGoalsScore] = useState(8);
  const [interventionsScore, setInterventionsScore] = useState(8);
  const [evaluationScore, setEvaluationScore] = useState(8);
  const [feedback, setFeedback] = useState("");
  const [revisionRequired, setRevisionRequired] = useState(false);

  // Status/Messages
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const baseUrl = "http://localhost:5000/api";

  // Check auth and fetch data
  useEffect(() => {
    const token = localStorage.getItem("nurseplan_token");
    const storedUser = localStorage.getItem("nurseplan_user");
    if (!token || !storedUser) {
      router.push("/auth");
      return;
    }
    
    const parsedUser = JSON.parse(storedUser);
    if (parsedUser.role !== "instructor") {
      router.push("/auth");
      return;
    }
    
    setUser(parsedUser);
    fetchInstructorData(token);
  }, []);

  const fetchInstructorData = async (token: string) => {
    setError("");
    try {
      const headers = { "Authorization": `Bearer ${token}` };
      
      const [submissionsRes, logsRes, usersRes] = await Promise.all([
        fetch(`${baseUrl}/careplans`, { headers }),
        fetch(`${baseUrl}/clinical-logs`, { headers }),
        // Reuse admin users endpoint, standard RBAC handles this
        fetch(`${baseUrl}/admin/users`, { headers })
      ]);

      if (submissionsRes.ok) setSubmissions(await submissionsRes.json());
      if (logsRes.ok) setLogs(await logsRes.json());
      if (usersRes.ok) {
        const allUsers = await usersRes.json();
        setCohort(allUsers.filter((u: any) => u.role === "student"));
      }
    } catch (err) {
      console.warn("Express API not running, using offline instructor mock data.");
      // Fallback mock data
      setSubmissions([
        { 
          id: "cp-1", 
          title: "Acute Airway Management Plan", 
          status: "submitted", 
          student_name: "John Doe", 
          patient_initials: "K. R.", 
          medical_diagnosis: "Pneumonia", 
          submitted_at: "2026-06-13",
          subjective_data: "Patient reports shortness of breath, chest tightness, stating 'I feel like I am suffocating when lying flat.'",
          objective_data: "SpO2 91% on room air, RR 24, HR 98. Crackles on bilateral lower lobe auscultation.",
          nursing_diagnosis: '[{"code":"00031","name":"Ineffective Airway Clearance"}]',
          short_term_goals: '["Patient will maintain oxygen saturation above 94% within 4 hours."]',
          long_term_goals: '["Patient will expectorate secretions freely by end of admission."]',
          interventions: '[{"description":"Auscultate breath sounds and monitor respiratory rates every 2 hours.","priority":"high","rationale":"Ongoing monitoring tracks obstruction and therapeutic adjustments."}]',
          implementation_notes: "Oxygen administered via NC at 2L. Auscultated at 1100, respiratory rate is 21.",
          evaluation_status: "partially_met",
          evaluation_notes: "Respiratory rate reduced to normal, crackles still present in left lobe."
        },
        { 
          id: "cp-3", 
          title: "Post-op Wound Care Plan", 
          status: "submitted", 
          student_name: "Jane Smith", 
          patient_initials: "T. J.", 
          medical_diagnosis: "Appendectomy", 
          submitted_at: "2026-06-12",
          subjective_data: "Patient reports sharp incision pain rated 7/10.",
          objective_data: "Incision intact with minimal serosanguinous drainage, mild surrounding erythema.",
          nursing_diagnosis: '[{"code":"00132","name":"Acute Pain"}]',
          short_term_goals: '["Patient will rate pain below 3/10 within 1 hour."]',
          long_term_goals: '["Patient will mobilize to door by day 2."]',
          interventions: '[{"description":"Administer ordered PRN analgesics as requested.","priority":"high","rationale":"Pharmacological therapy acts rapidly on pain receptors."}]',
          implementation_notes: "Pain medication administered at 1000.",
          evaluation_status: "met",
          evaluation_notes: "Pain rated 2/10 at 1100."
        }
      ]);
      setLogs([
        { id: "log-2", procedure_name: "Medication Administration", ward: "Cardiology", hours: 2.0, student_name: "John Doe", supervisor_name: "RN Smith", competency_status: "assisted", approval_status: "pending", date: "2026-06-13" },
        { id: "log-3", procedure_name: "Wound Dressing", ward: "Surgical", hours: 4.0, student_name: "Jane Smith", supervisor_name: "RN Sterling", competency_status: "supervised", approval_status: "pending", date: "2026-06-12" }
      ]);
      setCohort([
        { id: "stud-001", name: "John Doe", email: "john.doe@greenfield.edu", status: "active", created_at: "2026-06-12" },
        { id: "stud-002", name: "Jane Smith", email: "jane.smith@greenfield.edu", status: "active", created_at: "2026-06-11" }
      ]);
    }
  };

  // Submit Care Plan Grade (out of 50)
  const handleGradeSubmission = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");

    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/careplans/${selectedSubmission.id}/grade`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          assessmentScore,
          diagnosisScore,
          goalsScore,
          interventionsScore,
          evaluationScore,
          feedback,
          revisionRequired
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setSuccess(revisionRequired ? "Revision request dispatched!" : "Grading rubric submitted successfully!");
      setSelectedSubmission(null);
      fetchInstructorData(token!);
    } catch (err) {
      // Offline fallback grading update
      const total = assessmentScore + diagnosisScore + goalsScore + interventionsScore + evaluationScore;
      setSubmissions(submissions.map(s => 
        s.id === selectedSubmission.id 
          ? { ...s, status: revisionRequired ? 'revision_requested' : 'reviewed', grade: total }
          : s
      ));
      setSuccess(`Graded successfully out of 50! Total: ${total} (Offline Mode)`);
      setSelectedSubmission(null);
    } finally {
      setLoading(false);
    }
  };

  // Approve / Reject clinical logs
  const handleProcessLog = async (logId: string, status: "approved" | "rejected") => {
    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/clinical-logs/${logId}/approve`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ status })
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error);
      }

      setSuccess(`Timesheet log ${status} successfully.`);
      fetchInstructorData(token!);
    } catch (err) {
      setLogs(logs.filter(l => l.id !== logId));
      setSuccess(`Timesheet log ${status} locally (Offline Mode)`);
    }
  };

  const logout = () => {
    localStorage.removeItem("nurseplan_token");
    localStorage.removeItem("nurseplan_user");
    router.push("/");
  };

  // Summary Metrics
  const pendingLogsCount = logs.filter(l => l.approval_status === "pending").length;
  const pendingSubmissionsCount = submissions.filter(s => s.status === "submitted").length;

  return (
    <div className="flex-1 flex flex-col md:flex-row min-h-screen bg-slate-50 font-sans">
      
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-slate-900 text-white flex flex-col justify-between p-6">
        <div className="space-y-8">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-teal-500 flex items-center justify-center text-white">
              <Stethoscope className="w-5 h-5" />
            </div>
            <span className="text-lg font-bold tracking-tight">NursePlan Pro</span>
          </div>

          <div className="space-y-1">
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider px-3 mb-2">Faculty Hub</div>
            <button
              onClick={() => { setActiveTab("submissions"); setSelectedSubmission(null); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === "submissions" ? "bg-teal-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
            >
              <FileText className="w-4 h-4" /> Assignments ({pendingSubmissionsCount})
            </button>
            <button
              onClick={() => { setActiveTab("logs"); setSelectedSubmission(null); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === "logs" ? "bg-teal-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
            >
              <Clock className="w-4 h-4" /> Logs Approvals ({pendingLogsCount})
            </button>
            <button
              onClick={() => { setActiveTab("students"); setSelectedSubmission(null); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === "students" ? "bg-teal-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
            >
              <Users className="w-4 h-4" /> My Students
            </button>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800 space-y-4">
          <div className="px-3">
            <div className="text-xs font-semibold text-slate-300 truncate">{user?.name}</div>
            <div className="text-[10px] text-slate-500 truncate">{user?.email}</div>
          </div>
          <button 
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-semibold text-slate-400 hover:bg-slate-850 hover:text-rose-400 transition-colors"
          >
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>
      </aside>

      {/* Main Panel Content */}
      <main className="flex-1 p-6 md:p-10 space-y-8 overflow-y-auto max-w-7xl mx-auto w-full">
        
        {/* Header Summary */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Instructor Portal</h1>
            <p className="text-sm text-slate-500 mt-1">Medical-Surgical Nursing cohort</p>
          </div>
        </div>

        {/* Global status banner */}
        {success && (
          <div className="p-3.5 bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-semibold rounded-2xl">
            {success}
          </div>
        )}

        {/* Selected Care Plan Grading Workspace */}
        {selectedSubmission ? (
          <div className="bg-white rounded-3xl border border-slate-200/60 shadow-xl overflow-hidden grid lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-100 animate-slide-up">
            
            {/* Left Hand: Student Care Plan contents */}
            <div className="lg:col-span-7 p-6 md:p-8 space-y-6 overflow-y-auto max-h-[80vh] custom-scrollbar">
              <div className="flex justify-between items-start border-b border-slate-100 pb-4">
                <div>
                  <h2 className="text-lg font-bold text-slate-800">{selectedSubmission.title}</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    By Student: {selectedSubmission.student_name} • Submitted: {selectedSubmission.submitted_at}
                  </p>
                </div>
                <button 
                  onClick={() => setSelectedSubmission(null)}
                  className="text-slate-400 hover:text-slate-600 text-xs font-semibold"
                >
                  Cancel Review
                </button>
              </div>

              <div className="space-y-4 text-xs text-slate-650 leading-relaxed">
                <div>
                  <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[10px] text-slate-500">Patient demographics (HIPAA)</h4>
                  <p className="mt-1 bg-slate-50 p-3 rounded-xl border border-slate-100">
                    Initials: {selectedSubmission.patient_initials} • Med Diagnosis: {selectedSubmission.medical_diagnosis}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[10px] text-slate-500">Subjective Assessment</h4>
                    <p className="mt-1 bg-slate-50 p-3 rounded-xl border border-slate-100 min-h-24 whitespace-pre-line">{selectedSubmission.subjective_data}</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[10px] text-slate-500">Objective Assessment</h4>
                    <p className="mt-1 bg-slate-50 p-3 rounded-xl border border-slate-100 min-h-24 whitespace-pre-line">{selectedSubmission.objective_data}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[10px] text-slate-500">Selected Diagnoses</h4>
                  <div className="mt-1 bg-slate-50 p-3 rounded-xl border border-slate-100 flex flex-wrap gap-1.5">
                    {JSON.parse(selectedSubmission.nursing_diagnosis || "[]").map((d: any) => (
                      <span key={d.code} className="bg-brand-50 text-brand-700 font-bold px-2.5 py-0.5 rounded text-[10px]">
                        {d.name} ({d.code})
                      </span>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[10px] text-slate-500">Short-Term Goals (SMART)</h4>
                    <ul className="mt-1 bg-slate-50 p-3 rounded-xl border border-slate-100 list-disc pl-5 space-y-1">
                      {JSON.parse(selectedSubmission.short_term_goals || "[]").map((g: any, i: number) => (
                        <li key={i}>{g}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[10px] text-slate-500">Long-Term Goals (SMART)</h4>
                    <ul className="mt-1 bg-slate-50 p-3 rounded-xl border border-slate-100 list-disc pl-5 space-y-1">
                      {JSON.parse(selectedSubmission.long_term_goals || "[]").map((g: any, i: number) => (
                        <li key={i}>{g}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[10px] text-slate-500">Planned Interventions & Rationales</h4>
                  <div className="mt-1 space-y-2">
                    {JSON.parse(selectedSubmission.interventions || "[]").map((item: any, i: number) => (
                      <div key={i} className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1">
                        <div><strong>Action:</strong> {item.description}</div>
                        <div className="text-[10px] text-slate-400"><strong>Rationale:</strong> {item.rationale}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[10px] text-slate-500">Implementation Action log</h4>
                    <p className="mt-1 bg-slate-50 p-3 rounded-xl border border-slate-100 min-h-16">{selectedSubmission.implementation_notes}</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[10px] text-slate-500">Outcome Evaluation</h4>
                    <div className="mt-1 bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1">
                      <div>Status: <span className="font-bold capitalize">{selectedSubmission.evaluation_status}</span></div>
                      <p>{selectedSubmission.evaluation_notes}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Hand: Care Plan Grading Rubric Form */}
            <form onSubmit={handleGradeSubmission} className="lg:col-span-5 p-6 md:p-8 space-y-6 flex flex-col justify-between overflow-y-auto max-h-[80vh] custom-scrollbar bg-slate-50/50">
              <div className="space-y-1 border-b border-slate-200 pb-4">
                <h3 className="font-bold text-slate-800 text-sm">Grading Rubric Breakdown</h3>
                <p className="text-[10px] text-slate-400">Total max score: 50 marks (10 marks per section)</p>
              </div>

              <div className="space-y-4">
                {[
                  { key: "assessment", label: "Assessment quality", val: assessmentScore, set: setAssessmentScore },
                  { key: "diagnosis", label: "Diagnosis accuracy", val: diagnosisScore, set: setDiagnosisScore },
                  { key: "goals", label: "SMART Goals framing", val: goalsScore, set: setGoalsScore },
                  { key: "interventions", label: "Interventions & Rationales", val: interventionsScore, set: setInterventionsScore },
                  { key: "evaluation", label: "Clinical Evaluation accuracy", val: evaluationScore, set: setEvaluationScore }
                ].map(item => (
                  <div key={item.key} className="flex items-center justify-between gap-4">
                    <span className="text-xs font-semibold text-slate-700">{item.label}</span>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        min={0}
                        max={10}
                        required
                        value={item.val}
                        onChange={(e) => item.set(Math.min(10, Math.max(0, parseInt(e.target.value) || 0)))}
                        className="w-14 h-9 border border-slate-200 rounded-lg text-center text-xs font-bold bg-white"
                      />
                      <span className="text-[10px] text-slate-400 font-semibold">/ 10</span>
                    </div>
                  </div>
                ))}

                <div className="pt-2 flex items-center justify-between text-sm font-bold text-slate-800 border-t border-slate-200">
                  <span>Aggregate Total Score:</span>
                  <span>
                    {assessmentScore + diagnosisScore + goalsScore + interventionsScore + evaluationScore} / 50
                  </span>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Reviewer Feedback & Comments</label>
                  <textarea
                    rows={3}
                    placeholder="Provide specific pedagogical feedback on weaknesses, clinical links..."
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    className="w-full p-3 border border-slate-200 rounded-xl text-xs bg-white"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="revision"
                    checked={revisionRequired}
                    onChange={(e) => setRevisionRequired(e.target.checked)}
                    className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500"
                  />
                  <label htmlFor="revision" className="text-xs font-semibold text-slate-700 cursor-pointer">
                    Request revision (Requires student rewrite)
                  </label>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full h-10 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-400 text-white font-bold rounded-xl text-xs transition-all mt-4"
              >
                {loading ? "Submitting Grade..." : revisionRequired ? "Disptach Revision Request" : "Submit Grade Report"}
              </button>
            </form>
          </div>
        ) : (
          /* Main Tab Panels */
          <div className="space-y-6">
            
            {/* Tabs toggler */}
            <div className="flex border-b border-slate-200">
              <button
                onClick={() => setActiveTab("submissions")}
                className={`pb-3 px-6 text-sm font-bold border-b-2 transition-all ${activeTab === "submissions" ? "border-teal-600 text-teal-600 font-extrabold" : "border-transparent text-slate-400 hover:text-slate-600"}`}
              >
                Submitted Care Plans ({pendingSubmissionsCount})
              </button>
              <button
                onClick={() => setActiveTab("logs")}
                className={`pb-3 px-6 text-sm font-bold border-b-2 transition-all ${activeTab === "logs" ? "border-teal-600 text-teal-600 font-extrabold" : "border-transparent text-slate-400 hover:text-slate-600"}`}
              >
                Clinical Logs approvals ({pendingLogsCount})
              </button>
              <button
                onClick={() => setActiveTab("students")}
                className={`pb-3 px-6 text-sm font-bold border-b-2 transition-all ${activeTab === "students" ? "border-teal-600 text-teal-600 font-extrabold" : "border-transparent text-slate-400 hover:text-slate-600"}`}
              >
                My Students ({cohort.length})
              </button>
            </div>

            {/* TAB 1: Care plan submissions list */}
            {activeTab === "submissions" && (
              <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="font-bold text-slate-700">Assignments Inbox</h3>
                  <span className="text-xs text-slate-400">Click Review to open rubric grading</span>
                </div>
                <div className="divide-y divide-slate-100">
                  {submissions.length === 0 ? (
                    <div className="p-12 text-center text-slate-400">No care plan submissions currently pending.</div>
                  ) : (
                    submissions.map(sub => (
                      <div key={sub.id} className="p-6 hover:bg-slate-50/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-colors">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-slate-800 text-sm">{sub.title}</h4>
                            <span className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase ${
                              sub.status === 'submitted' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                              sub.status === 'revision_requested' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                              'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            }`}>
                              {sub.status}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400">
                            Student: <strong>{sub.student_name}</strong> • Patient: {sub.patient_initials} • Diagnosis: {sub.medical_diagnosis}
                          </p>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          {sub.total_score && (
                            <span className="text-xs font-bold text-slate-500 mr-2">Grade: {sub.total_score}/50</span>
                          )}
                          <button
                            onClick={() => setSelectedSubmission(sub)}
                            className="inline-flex h-9 px-4.5 items-center justify-center rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-md shadow-teal-600/10"
                          >
                            Review & Grade
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: Pending Clinical Logs approvals */}
            {activeTab === "logs" && (
              <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="font-bold text-slate-700">Logged Procedures</h3>
                  <span className="text-xs text-slate-400">Approve clinical hours logs</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="bg-slate-50/50 text-slate-400 text-xs font-bold border-b border-slate-100">
                        <th className="px-6 py-3">Student</th>
                        <th className="px-6 py-3">Procedure Name</th>
                        <th className="px-6 py-3">Date / Ward</th>
                        <th className="px-6 py-3">Supervisor</th>
                        <th className="px-6 py-3">Hours</th>
                        <th className="px-6 py-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-600">
                      {logs.filter(l => l.approval_status === "pending").length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-slate-400">No clinical logs require verification.</td>
                        </tr>
                      ) : (
                        logs.filter(l => l.approval_status === "pending").map(log => (
                          <tr key={log.id} className="hover:bg-slate-50/20">
                            <td className="px-6 py-4 font-bold text-slate-800">{log.student_name}</td>
                            <td className="px-6 py-4 font-medium text-slate-700">{log.procedure_name}</td>
                            <td className="px-6 py-4">{log.date} • {log.ward}</td>
                            <td className="px-6 py-4">{log.supervisor_name} ({log.competency_status})</td>
                            <td className="px-6 py-4 font-bold">{log.hours} hrs</td>
                            <td className="px-6 py-4 flex items-center gap-2">
                              <button
                                onClick={() => handleProcessLog(log.id, "approved")}
                                className="h-8 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded text-xs"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => handleProcessLog(log.id, "rejected")}
                                className="h-8 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold border border-rose-200 rounded text-xs"
                              >
                                Reject
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB 3: Students list */}
            {activeTab === "students" && (
              <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="font-bold text-slate-700">Enrolled Students</h3>
                  <span className="text-xs text-slate-400">Standardizing competencies tracker</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="bg-slate-50/50 text-slate-400 text-xs font-bold border-b border-slate-100">
                        <th className="px-6 py-3">Student Name</th>
                        <th className="px-6 py-3">Email Address</th>
                        <th className="px-6 py-3">Status</th>
                        <th className="px-6 py-3">Enrolled At</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-600">
                      {cohort.map(st => (
                        <tr key={st.id} className="hover:bg-slate-50/20">
                          <td className="px-6 py-4 font-bold text-slate-800">{st.name}</td>
                          <td className="px-6 py-4">{st.email}</td>
                          <td className="px-6 py-4">
                            <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-bold">
                              {st.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">{st.created_at?.substring(0, 10)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

          </div>
        )}
      </main>
    </div>
  );
}
