import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NursePlan Pro | Clinical Care Plan Management",
  description: "Create professional nursing care plans in minutes. Smart care plan builder, clinical logbook, NANDA diagnoses library, and instructor review tools.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased min-h-screen flex flex-col bg-slate-50 text-slate-900">
        {children}
      </body>
    </html>
  );
}
