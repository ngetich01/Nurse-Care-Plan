"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { 
  Stethoscope, 
  Users, 
  School, 
  ShieldAlert, 
  Settings, 
  LogOut, 
  TrendingUp, 
  CreditCard,
  FileText,
  Clock,
  Award,
  Activity,
  CheckCircle,
  AlertTriangle
} from "lucide-react";

export default function AdminDashboard() {
  const router = useRouter();

  // State
  const [user, setUser] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [schools, setSchools] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"users" | "schools" | "settings">("users");

  // Form handling
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const baseUrl = "http://localhost:5000/api";

  // Check auth and fetch data
  useEffect(() => {
    const token = localStorage.getItem("nurseplan_token");
    const storedUser = localStorage.getItem("nurseplan_user");
    if (!token || !storedUser) {
      router.push("/auth");
      return;
    }
    
    const parsedUser = JSON.parse(storedUser);
    if (parsedUser.role !== "school_admin" && parsedUser.role !== "system_admin") {
      router.push("/auth");
      return;
    }
    
    setUser(parsedUser);
    fetchAdminData(token);
  }, []);

  const fetchAdminData = async (token: string) => {
    setError("");
    try {
      const headers = { "Authorization": `Bearer ${token}` };
      
      const [usersRes, schoolsRes, analyticsRes] = await Promise.all([
        fetch(`${baseUrl}/admin/users`, { headers }),
        fetch(`${baseUrl}/admin/schools`, { headers }),
        fetch(`${baseUrl}/admin/analytics`, { headers })
      ]);

      if (usersRes.ok) setUsers(await usersRes.json());
      if (schoolsRes.ok) setSchools(await schoolsRes.json());
      if (analyticsRes.ok) setAnalytics(await analyticsRes.json());
    } catch (err) {
      console.warn("Express API not running, using offline admin mock data.");
      // Fallback mock values
      setUsers([
        { id: "usr-1", name: "John Doe", email: "john.doe@greenfield.edu", role: "student", status: "active", email_verified: true, created_at: "2026-06-12" },
        { id: "usr-2", name: "Jane Smith", email: "jane.smith@greenfield.edu", role: "student", status: "active", email_verified: true, created_at: "2026-06-11" },
        { id: "usr-3", name: "Dr. Sarah Jenkins", email: "sarah.jenkins@greenfield.edu", role: "instructor", status: "active", email_verified: true, created_at: "2026-06-10" }
      ]);
      setSchools([
        { id: "sch-001", name: "Greenfield Nursing College", subscription_plan: "School Premium", subscription_status: "active", created_at: "2026-06-01" },
        { id: "sch-002", name: "St. Jude Health Academy", subscription_plan: "School Standard", subscription_status: "active", created_at: "2026-06-01" }
      ]);
      setAnalytics({
        students: 2,
        instructors: 1,
        averageGrade: "44.5",
        gradedPlansCount: 2,
        totalClinicalHoursLogged: "18.0",
        totalClinicalHoursApproved: "8.0",
        proceduresSummary: [
          { procedure_name: "IV Insertion", count: 4 },
          { procedure_name: "Medication Administration", count: 3 },
          { procedure_name: "Wound Dressing", count: 2 }
        ]
      });
    }
  };

  // Toggle user status: suspend or activate
  const toggleUserStatus = async (userId: string, currentStatus: string) => {
    const newStatus = currentStatus === "active" ? "suspended" : "active";
    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/admin/users/${userId}/status`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ status: newStatus })
      });

      if (!res.ok) throw new Error("Failed to update user status");
      setSuccess("User status updated successfully.");
      fetchAdminData(token!);
    } catch (e) {
      // Offline fallback toggle
      setUsers(users.map(u => u.id === userId ? { ...u, status: newStatus } : u));
      setSuccess(`User status changed to ${newStatus} locally (Offline Mode)`);
    }
  };

  // Change school subscription plan
  const handleUpdateSubscription = async (schoolId: string, newPlan: string) => {
    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/admin/schools/${schoolId}/subscription`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ subscriptionPlan: newPlan })
      });

      if (!res.ok) throw new Error("Failed to modify subscription");
      setSuccess("School subscription tier modified.");
      fetchAdminData(token!);
    } catch (e) {
      setSchools(schools.map(s => s.id === schoolId ? { ...s, subscription_plan: newPlan } : s));
      setSuccess(`Subscription changed to ${newPlan} locally (Offline Mode)`);
    }
  };

  const logout = () => {
    localStorage.removeItem("nurseplan_token");
    localStorage.removeItem("nurseplan_user");
    router.push("/");
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row min-h-screen bg-slate-50 font-sans">
      
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-slate-900 text-white flex flex-col justify-between p-6">
        <div className="space-y-8">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-indigo-500 flex items-center justify-center text-white">
              <Stethoscope className="w-5 h-5" />
            </div>
            <span className="text-lg font-bold tracking-tight">NursePlan Pro</span>
          </div>

          <div className="space-y-1">
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider px-3 mb-2">Admin Dashboard</div>
            <button
              onClick={() => setActiveTab("users")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === "users" ? "bg-indigo-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
            >
              <Users className="w-4 h-4" /> User Accounts
            </button>
            <button
              onClick={() => setActiveTab("schools")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === "schools" ? "bg-indigo-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
            >
              <School className="w-4 h-4" /> School Cohorts
            </button>
            <button
              onClick={() => setActiveTab("settings")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === "settings" ? "bg-indigo-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
            >
              <Settings className="w-4 h-4" /> Configuration
            </button>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800 space-y-4">
          <div className="px-3">
            <div className="text-xs font-semibold text-slate-300 truncate">{user?.name}</div>
            <div className="text-[10px] text-slate-500 truncate">{user?.email}</div>
          </div>
          <button 
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-semibold text-slate-400 hover:bg-slate-850 hover:text-rose-400 transition-colors"
          >
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>
      </aside>

      {/* Main Panel Content */}
      <main className="flex-1 p-6 md:p-10 space-y-8 overflow-y-auto max-w-7xl mx-auto w-full">
        
        {/* Header Summary */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Administrative Center</h1>
            <p className="text-sm text-slate-500 mt-1">Management panels and payment tracking</p>
          </div>
        </div>

        {/* Global status banner */}
        {success && (
          <div className="p-3.5 bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-semibold rounded-2xl">
            {success}
          </div>
        )}

        {/* Analytics Summary Widget Grid */}
        {analytics && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">Students enrolled</span>
                <div className="p-2 bg-indigo-50 rounded-lg text-indigo-650"><Users className="w-4 h-4" /></div>
              </div>
              <div className="text-2xl font-extrabold text-slate-850">{analytics.students}</div>
              <div className="text-[10px] text-slate-400">Instructors: {analytics.instructors}</div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">Cohort GPA</span>
                <div className="p-2 bg-teal-50 rounded-lg text-teal-650"><Award className="w-4 h-4" /></div>
              </div>
              <div className="text-2xl font-extrabold text-slate-850">{analytics.averageGrade} <span className="text-xs text-slate-400">/ 50</span></div>
              <div className="text-[10px] text-slate-400">Across {analytics.gradedPlansCount} graded submissions</div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">Clinical Hours</span>
                <div className="p-2 bg-amber-50 rounded-lg text-amber-650"><Clock className="w-4 h-4" /></div>
              </div>
              <div className="text-2xl font-extrabold text-slate-850">{analytics.totalClinicalHoursApproved} <span className="text-xs text-slate-400">/ {analytics.totalClinicalHoursLogged} logged</span></div>
              <div className="text-[10px] text-slate-400">Instructor approved timecards</div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">Procedures</span>
                <div className="p-2 bg-rose-50 rounded-lg text-rose-650"><Activity className="w-4 h-4" /></div>
              </div>
              <div className="text-2xl font-extrabold text-slate-850">
                {analytics.proceduresSummary?.reduce((a: number, b: any) => a + (b.count || 0), 0) || 0}
              </div>
              <div className="text-[10px] text-slate-400 truncate">
                Top: {analytics.proceduresSummary?.[0]?.procedure_name || "None"}
              </div>
            </div>
          </div>
        )}

        {/* Tab panels */}
        <div className="space-y-6">
          
          {/* TAB 1: User list management */}
          {activeTab === "users" && (
            <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                <h3 className="font-bold text-slate-700">Account Management</h3>
                <span className="text-xs text-slate-400">Moderate permissions or suspend accounts</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50/50 text-slate-400 text-xs font-bold border-b border-slate-100">
                      <th className="px-6 py-3">Full Name</th>
                      <th className="px-6 py-3">Email Address</th>
                      <th className="px-6 py-3">System Role</th>
                      <th className="px-6 py-3">Verification</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-600">
                    {users.map(u => (
                      <tr key={u.id} className="hover:bg-slate-50/20">
                        <td className="px-6 py-4 font-bold text-slate-850">{u.name}</td>
                        <td className="px-6 py-4">{u.email}</td>
                        <td className="px-6 py-4 capitalize font-semibold">{u.role.replace("_", " ")}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${u.email_verified ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-slate-50 text-slate-400 border border-slate-150'}`}>
                            {u.email_verified ? 'Verified' : 'Pending'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-2.5 py-1 rounded-full text-xs font-bold capitalize ${u.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                            {u.status}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => toggleUserStatus(u.id, u.status)}
                            className={`px-3 py-1 text-xs font-bold rounded-lg border transition-all ${
                              u.status === "active" 
                                ? "bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-700" 
                                : "bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-700"
                            }`}
                          >
                            {u.status === "active" ? "Suspend" : "Activate"}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: Schools / Cohort subscription management */}
          {activeTab === "schools" && (
            <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                <h3 className="font-bold text-slate-700">Registered Institutes</h3>
                <span className="text-xs text-slate-400">Subscription plans management</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50/50 text-slate-400 text-xs font-bold border-b border-slate-100">
                      <th className="px-6 py-3">College Name</th>
                      <th className="px-6 py-3">Registered At</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3">Active Subscription Plan</th>
                      <th className="px-6 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-600">
                    {schools.map(s => (
                      <tr key={s.id} className="hover:bg-slate-50/20">
                        <td className="px-6 py-4 font-bold text-slate-850">{s.name}</td>
                        <td className="px-6 py-4">{s.created_at?.substring(0, 10)}</td>
                        <td className="px-6 py-4">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 capitalize">
                            {s.subscription_status}
                          </span>
                        </td>
                        <td className="px-6 py-4 font-bold text-slate-750">{s.subscription_plan}</td>
                        <td className="px-6 py-4">
                          <select
                            value={s.subscription_plan}
                            onChange={(e) => handleUpdateSubscription(s.id, e.target.value)}
                            className="h-8 px-2 border border-slate-200 rounded text-xs bg-white font-semibold"
                          >
                            <option value="Student Free">Student Free</option>
                            <option value="School Standard">School Standard</option>
                            <option value="School Premium">School Premium</option>
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: Global System settings configuration */}
          {activeTab === "settings" && (
            <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm p-6 space-y-6">
              <h3 className="font-bold text-slate-800 text-base">Platform Configuration</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wide">Security Controls</h4>
                  
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-700">Enforce Multi-Factor Auth (MFA)</span>
                      <input type="checkbox" defaultChecked className="w-4 h-4 text-indigo-650 rounded" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-700">GDPR audit tracking logs</span>
                      <input type="checkbox" defaultChecked className="w-4 h-4 text-indigo-650 rounded" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-700">HIPAA initials validation regex</span>
                      <input type="checkbox" defaultChecked className="w-4 h-4 text-indigo-650 rounded" />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wide">Integrations API</h4>
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Gemini API Token (AI Suggestion Coprocessor)</label>
                      <input type="password" placeholder="••••••••••••••••" className="w-full h-10 px-3 border border-slate-200 rounded-xl text-xs bg-white" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">AWS S3 Assets Bucket Name</label>
                      <input type="text" defaultValue="nurseplan-secure-records-s3" className="w-full h-10 px-3 border border-slate-200 rounded-xl text-xs bg-white font-mono" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}
