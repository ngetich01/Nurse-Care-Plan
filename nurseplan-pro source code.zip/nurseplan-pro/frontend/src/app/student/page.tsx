"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { 
  Stethoscope, 
  Activity, 
  FileText, 
  Clock, 
  CheckCircle2, 
  Plus, 
  UserPlus, 
  FolderGit2, 
  BookOpen, 
  LogOut, 
  TrendingUp, 
  Bell, 
  FileSignature, 
  Award,
  ChevronRight,
  ClipboardList,
  AlertCircle
} from "lucide-react";

export default function StudentDashboard() {
  const router = useRouter();
  
  // States
  const [user, setUser] = useState<any>(null);
  const [patients, setPatients] = useState<any[]>([]);
  const [carePlans, setCarePlans] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  
  // Modals / Inputs
  const [patientModal, setPatientModal] = useState(false);
  const [logModal, setLogModal] = useState(false);
  const [activeTab, setActiveTab] = useState<"plans" | "patients" | "logs">("plans");
  
  // Form values
  const [patientInitials, setPatientInitials] = useState("");
  const [patientAge, setPatientAge] = useState("");
  const [patientGender, setPatientGender] = useState("Female");
  const [patientWard, setPatientWard] = useState("ICU");
  const [patientBed, setPatientBed] = useState("");
  const [patientDiag, setPatientDiag] = useState("");
  const [patientHpi, setPatientHpi] = useState("");
  const [patientAllergies, setPatientAllergies] = useState("");
  const [patientMeds, setPatientMeds] = useState("");
  const [patientNotes, setPatientNotes] = useState("");

  const [logProcedure, setLogProcedure] = useState("IV Insertion");
  const [logHours, setLogHours] = useState("");
  const [logWard, setLogWard] = useState("ICU");
  const [logSupervisor, setLogSupervisor] = useState("");
  const [logCompetency, setLogCompetency] = useState("supervised");
  const [logReflection, setLogReflection] = useState("");
  const [logDate, setLogDate] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const baseUrl = "http://localhost:5000/api";

  // Check auth and fetch data
  useEffect(() => {
    const token = localStorage.getItem("nurseplan_token");
    const storedUser = localStorage.getItem("nurseplan_user");
    if (!token || !storedUser) {
      router.push("/auth");
      return;
    }
    
    const parsedUser = JSON.parse(storedUser);
    if (parsedUser.role !== "student") {
      router.push("/auth");
      return;
    }
    
    setUser(parsedUser);
    fetchDashboardData(token);
  }, []);

  const fetchDashboardData = async (token: string) => {
    setError("");
    try {
      const headers = { "Authorization": `Bearer ${token}` };
      
      const [patientsRes, careplansRes, logsRes, notifsRes] = await Promise.all([
        fetch(`${baseUrl}/patients`, { headers }),
        fetch(`${baseUrl}/careplans`, { headers }),
        fetch(`${baseUrl}/clinical-logs`, { headers }),
        fetch(`${baseUrl}/notifications`, { headers })
      ]);

      if (patientsRes.ok) setPatients(await patientsRes.json());
      if (careplansRes.ok) setCarePlans(await careplansRes.json());
      if (logsRes.ok) setLogs(await logsRes.json());
      if (notifsRes.ok) setNotifications(await notifsRes.json());
    } catch (err) {
      console.warn("Express API is not running, using offline local mock data.");
      // Fallback mock data for demonstration
      setPatients([
        { id: "pat-1", initials: "K. R.", age: 45, gender: "Male", ward: "Med-Surg", bed_number: "204B", admission_date: "2026-06-12", medical_diagnosis: "Pneumonia" },
        { id: "pat-2", initials: "S. T.", age: 67, gender: "Female", ward: "Cardiology", bed_number: "102A", admission_date: "2026-06-11", medical_diagnosis: "Congestive Heart Failure" }
      ]);
      setCarePlans([
        { id: "cp-1", title: "Acute Airway Management Plan", status: "reviewed", grade: 46.0, patient_initials: "K. R.", medical_diagnosis: "Pneumonia", updated_at: new Date().toISOString() },
        { id: "cp-2", title: "Fluid Balance & Cardiac Output Care", status: "draft", patient_initials: "S. T.", medical_diagnosis: "Congestive Heart Failure", updated_at: new Date().toISOString() }
      ]);
      setLogs([
        { id: "log-1", procedure_name: "IV Insertion", ward: "Med-Surg", hours: 4.0, supervisor_name: "RN Jenkins", competency_status: "supervised", approval_status: "approved", date: "2026-06-12" },
        { id: "log-2", procedure_name: "Medication Administration", ward: "Cardiology", hours: 2.0, supervisor_name: "RN Smith", competency_status: "assisted", approval_status: "pending", date: "2026-06-13" }
      ]);
      setNotifications([
        { id: "n-1", title: "Care Plan Graded", message: "Your Pneumonia care plan has been reviewed: 46/50.", type: "grade", read: false }
      ]);
    }
  };

  const handleCreatePatient = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");

    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/patients`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          initials: patientInitials,
          age: patientAge,
          gender: patientGender,
          ward: patientWard,
          bedNumber: patientBed,
          admissionDate: new Date().toISOString().substring(0, 10),
          medicalDiagnosis: patientDiag,
          historyOfPresentIllness: patientHpi,
          allergies: patientAllergies,
          currentMedications: patientMeds,
          notes: patientNotes
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to create patient");

      setSuccess("Patient record created successfully!");
      setPatientModal(false);
      
      // Reset fields
      setPatientInitials("");
      setPatientAge("");
      setPatientBed("");
      setPatientDiag("");
      setPatientHpi("");
      setPatientAllergies("");
      setPatientMeds("");
      setPatientNotes("");

      fetchDashboardData(token!);
    } catch (err: any) {
      // Offline fallback push
      const newPat = {
        id: `pat-${Date.now()}`,
        initials: patientInitials.toUpperCase(),
        age: parseInt(patientAge),
        gender: patientGender,
        ward: patientWard,
        bed_number: patientBed,
        admission_date: new Date().toISOString().substring(0, 10),
        medical_diagnosis: patientDiag
      };
      setPatients([newPat, ...patients]);
      setSuccess("Patient profile created locally (Offline Mode)");
      setPatientModal(false);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateLog = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");

    try {
      const token = localStorage.getItem("nurseplan_token");
      const res = await fetch(`${baseUrl}/clinical-logs`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          procedureName: logProcedure,
          date: logDate || new Date().toISOString().substring(0, 10),
          ward: logWard,
          supervisorName: logSupervisor,
          reflectionNotes: logReflection,
          competencyStatus: logCompetency,
          hours: logHours
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to submit log");

      setSuccess("Clinical log submitted successfully!");
      setLogModal(false);
      fetchDashboardData(token!);
    } catch (err: any) {
      const newLog = {
        id: `log-${Date.now()}`,
        procedure_name: logProcedure,
        ward: logWard,
        hours: parseFloat(logHours),
        supervisor_name: logSupervisor,
        competency_status: logCompetency,
        approval_status: "pending",
        date: logDate || new Date().toISOString().substring(0, 10)
      };
      setLogs([newLog, ...logs]);
      setSuccess("Clinical log recorded locally (Offline Mode)");
      setLogModal(false);
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem("nurseplan_token");
    localStorage.removeItem("nurseplan_user");
    router.push("/");
  };

  // Calculations
  const totalHoursLogged = logs.reduce((sum, log) => sum + (parseFloat(log.hours) || 0), 0);
  const totalHoursApproved = logs
    .filter((l) => l.approval_status === "approved")
    .reduce((sum, log) => sum + (parseFloat(log.hours) || 0), 0);

  const gradedPlans = carePlans.filter((cp) => cp.status === "reviewed" && cp.grade);
  const averageGrade = gradedPlans.length > 0 
    ? (gradedPlans.reduce((sum, cp) => sum + parseFloat(cp.grade), 0) / gradedPlans.length).toFixed(1)
    : "N/A";

  return (
    <div className="flex-1 flex flex-col md:flex-row min-h-screen bg-slate-50">
      
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-slate-900 text-white flex flex-col justify-between p-6">
        <div className="space-y-8">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-brand-500 flex items-center justify-center text-white">
              <Stethoscope className="w-5 h-5" />
            </div>
            <span className="text-lg font-bold tracking-tight">NursePlan Pro</span>
          </div>

          <div className="space-y-1">
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider px-3 mb-2">Student Hub</div>
            <button
              onClick={() => setActiveTab("plans")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === "plans" ? "bg-brand-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
            >
              <FileText className="w-4 h-4" /> Care Plans
            </button>
            <button
              onClick={() => setActiveTab("patients")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === "patients" ? "bg-brand-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
            >
              <Activity className="w-4 h-4" /> Patient Records
            </button>
            <button
              onClick={() => setActiveTab("logs")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === "logs" ? "bg-brand-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
            >
              <Clock className="w-4 h-4" /> Clinical Logbook
            </button>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800 space-y-4">
          <div className="px-3">
            <div className="text-xs font-semibold text-slate-300 truncate">{user?.name}</div>
            <div className="text-[10px] text-slate-500 truncate">{user?.email}</div>
          </div>
          <button 
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-semibold text-slate-400 hover:bg-slate-850 hover:text-rose-400 transition-colors"
          >
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>
      </aside>

      {/* Main Panel Content */}
      <main className="flex-1 p-6 md:p-10 space-y-8 overflow-y-auto max-w-7xl mx-auto w-full">
        
        {/* Header Summary */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Student Dashboard</h1>
            <p className="text-sm text-slate-500 mt-1">Greenfield Nursing College Program</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => setPatientModal(true)}
              className="inline-flex h-10 px-4 items-center justify-center rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold shadow-sm gap-1.5 transition-all"
            >
              <UserPlus className="w-4 h-4 text-slate-500" /> Add Patient
            </button>
            <button
              onClick={() => setLogModal(true)}
              className="inline-flex h-10 px-4 items-center justify-center rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold shadow-sm gap-1.5 transition-all"
            >
              <Clock className="w-4 h-4 text-slate-500" /> Log Hours
            </button>
            <Link
              href="/builder"
              className="inline-flex h-10 px-5 items-center justify-center rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold shadow-md shadow-brand-600/10 gap-1.5 transition-all"
            >
              <Plus className="w-4 h-4" /> Create Care Plan
            </Link>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">Total Patients</span>
              <div className="p-2 bg-brand-50 rounded-lg text-brand-600"><Activity className="w-4 h-4" /></div>
            </div>
            <div className="text-2xl font-extrabold text-slate-850">{patients.length}</div>
            <div className="text-[10px] text-slate-400">Secure HIPAA profiles logged</div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">Care Plans</span>
              <div className="p-2 bg-teal-50 rounded-lg text-teal-600"><FolderGit2 className="w-4 h-4" /></div>
            </div>
            <div className="text-2xl font-extrabold text-slate-850">{carePlans.length}</div>
            <div className="text-[10px] text-slate-400">
              {carePlans.filter(cp => cp.status === 'draft').length} drafts / {carePlans.filter(cp => cp.status !== 'draft').length} submitted
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">Clinical Hours</span>
              <div className="p-2 bg-amber-50 rounded-lg text-amber-600"><Clock className="w-4 h-4" /></div>
            </div>
            <div className="text-2xl font-extrabold text-slate-850">{totalHoursApproved} <span className="text-xs text-slate-400">/ {totalHoursLogged} logged</span></div>
            <div className="text-[10px] text-slate-400">Instructor approved timesheets</div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">Average Score</span>
              <div className="p-2 bg-purple-50 rounded-lg text-purple-600"><Award className="w-4 h-4" /></div>
            </div>
            <div className="text-2xl font-extrabold text-slate-850">{averageGrade} <span className="text-xs text-slate-400">/ 50</span></div>
            <div className="text-[10px] text-slate-400">Graded by clinical instructor</div>
          </div>
        </div>

        {/* Notifications and Alerts */}
        {notifications.length > 0 && (
          <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm p-5 space-y-3.5">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wide flex items-center gap-1.5">
              <Bell className="w-4 h-4 text-brand-500" /> Recent Notifications
            </h3>
            <div className="divide-y divide-slate-100">
              {notifications.map((n) => (
                <div key={n.id} className="py-2.5 flex items-start gap-3 text-sm">
                  <span className="w-2 h-2 rounded-full bg-brand-600 mt-1.5 flex-shrink-0"></span>
                  <div className="flex-1">
                    <div className="font-bold text-slate-700">{n.title}</div>
                    <div className="text-slate-500 text-xs mt-0.5">{n.message}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tabs Panels */}
        <div className="space-y-4">
          <div className="flex border-b border-slate-200">
            <button
              onClick={() => setActiveTab("plans")}
              className={`pb-3 px-6 text-sm font-bold border-b-2 transition-all ${activeTab === "plans" ? "border-brand-600 text-brand-600 font-extrabold" : "border-transparent text-slate-400 hover:text-slate-600"}`}
            >
              My Care Plans
            </button>
            <button
              onClick={() => setActiveTab("patients")}
              className={`pb-3 px-6 text-sm font-bold border-b-2 transition-all ${activeTab === "patients" ? "border-brand-600 text-brand-600 font-extrabold" : "border-transparent text-slate-400 hover:text-slate-600"}`}
            >
              Patient Logs
            </button>
            <button
              onClick={() => setActiveTab("logs")}
              className={`pb-3 px-6 text-sm font-bold border-b-2 transition-all ${activeTab === "logs" ? "border-brand-600 text-brand-600 font-extrabold" : "border-transparent text-slate-400 hover:text-slate-600"}`}
            >
              Procedure Timesheets
            </button>
          </div>

          {/* Active Tab rendering */}
          {activeTab === "plans" && (
            <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                <h3 className="font-bold text-slate-700">Digital Care Plans</h3>
                <span className="text-xs text-slate-400">Click a draft to edit or submit</span>
              </div>
              <div className="divide-y divide-slate-100">
                {carePlans.length === 0 ? (
                  <div className="p-12 text-center text-slate-400 text-sm">
                    No care plans created yet. Click "Create Care Plan" to get started.
                  </div>
                ) : (
                  carePlans.map((cp) => (
                    <div key={cp.id} className="p-6 hover:bg-slate-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-colors">
                      <div className="space-y-1">
                        <h4 className="font-bold text-slate-800 text-sm">{cp.title}</h4>
                        <p className="text-xs text-slate-500">
                          Patient: {cp.patient_initials} • Medical Dx: {cp.medical_diagnosis}
                        </p>
                      </div>

                      <div className="flex items-center gap-4">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold capitalize ${
                          cp.status === 'draft' ? 'bg-slate-100 text-slate-700' :
                          cp.status === 'submitted' ? 'bg-amber-100 text-amber-700 animate-pulse' :
                          cp.status === 'revision_requested' ? 'bg-rose-100 text-rose-700' :
                          'bg-emerald-100 text-emerald-700'
                        }`}>
                          {cp.status === 'reviewed' ? 'Graded' : cp.status.replace('_', ' ')}
                        </span>

                        {cp.grade && (
                          <div className="text-right">
                            <span className="text-sm font-extrabold text-slate-800">{cp.grade}</span>
                            <span className="text-[10px] text-slate-400 block">Grade /50</span>
                          </div>
                        )}

                        <Link
                          href={`/builder?id=${cp.id}`}
                          className="inline-flex h-9 px-3 items-center justify-center rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold shadow-sm"
                        >
                          {cp.status === "draft" || cp.status === "revision_requested" ? "Edit Plan" : "View Details"}
                        </Link>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {activeTab === "patients" && (
            <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                <h3 className="font-bold text-slate-700">Patient Directory (HIPAA initials only)</h3>
                <button
                  onClick={() => setPatientModal(true)}
                  className="inline-flex h-8 px-3 items-center justify-center rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
                >
                  New Record
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50/50 text-slate-400 text-xs font-bold border-b border-slate-100">
                      <th className="px-6 py-3">Initials</th>
                      <th className="px-6 py-3">Age/Gender</th>
                      <th className="px-6 py-3">Location</th>
                      <th className="px-6 py-3">Medical Diagnosis</th>
                      <th className="px-6 py-3">Admission Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-600">
                    {patients.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-slate-400">No patient logs recorded.</td>
                      </tr>
                    ) : (
                      patients.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-50/20">
                          <td className="px-6 py-4 font-bold text-slate-800">{p.initials}</td>
                          <td className="px-6 py-4">{p.age} yrs / {p.gender}</td>
                          <td className="px-6 py-4">{p.ward} • Bed {p.bed_number}</td>
                          <td className="px-6 py-4 font-medium text-slate-700">{p.medical_diagnosis}</td>
                          <td className="px-6 py-4">{p.admission_date}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "logs" && (
            <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                <h3 className="font-bold text-slate-700">Procedure Logbook</h3>
                <button
                  onClick={() => setLogModal(true)}
                  className="inline-flex h-8 px-3 items-center justify-center rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
                >
                  Log Procedure
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50/50 text-slate-400 text-xs font-bold border-b border-slate-100">
                      <th className="px-6 py-3">Procedure</th>
                      <th className="px-6 py-3">Date</th>
                      <th className="px-6 py-3">Supervisor</th>
                      <th className="px-6 py-3">Competency</th>
                      <th className="px-6 py-3">Hours</th>
                      <th className="px-6 py-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-600">
                    {logs.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-8 text-center text-slate-400">No procedures logged yet.</td>
                      </tr>
                    ) : (
                      logs.map((log) => (
                        <tr key={log.id} className="hover:bg-slate-50/20">
                          <td className="px-6 py-4 font-bold text-slate-800">{log.procedure_name}</td>
                          <td className="px-6 py-4">{log.date}</td>
                          <td className="px-6 py-4">{log.supervisor_name}</td>
                          <td className="px-6 py-4 capitalize">{log.competency_status}</td>
                          <td className="px-6 py-4 font-semibold">{log.hours} hrs</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold capitalize ${
                              log.approval_status === "approved" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" :
                              log.approval_status === "rejected" ? "bg-rose-50 text-rose-700 border border-rose-200" :
                              "bg-amber-50 text-amber-700 border border-amber-200"
                            }`}>
                              {log.approval_status}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* MODAL 1: ADD PATIENT (HIPAA Compliant) */}
      {patientModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full max-h-[85vh] flex flex-col animate-slide-up">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-800">Add Patient Log</h3>
                <p className="text-[10px] text-slate-400 italic">HIPAA Compliance Enforced — Initials only</p>
              </div>
              <button onClick={() => setPatientModal(false)} className="text-slate-400 hover:text-slate-600 font-bold">Close</button>
            </div>
            
            <form onSubmit={handleCreatePatient} className="flex-1 p-6 space-y-4 overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Initials</label>
                  <input
                    type="text"
                    required
                    maxLength={3}
                    placeholder="M.K."
                    value={patientInitials}
                    onChange={(e) => setPatientInitials(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Age</label>
                  <input
                    type="number"
                    required
                    placeholder="65"
                    value={patientAge}
                    onChange={(e) => setPatientAge(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Gender</label>
                  <select
                    value={patientGender}
                    onChange={(e) => setPatientGender(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm bg-white"
                  >
                    <option>Female</option>
                    <option>Male</option>
                    <option>Non-binary</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Ward / Unit</label>
                  <input
                    type="text"
                    required
                    placeholder="Medical-Surg B"
                    value={patientWard}
                    onChange={(e) => setPatientWard(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Bed Number</label>
                  <input
                    type="text"
                    required
                    placeholder="402-A"
                    value={patientBed}
                    onChange={(e) => setPatientBed(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Primary Medical Diagnosis</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Chronic Kidney Disease, Post-Op Abdominal Resection"
                  value={patientDiag}
                  onChange={(e) => setPatientDiag(e.target.value)}
                  className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">History of Present Illness (HPI)</label>
                <textarea
                  rows={2}
                  placeholder="Brief summary of symptoms prior to admission..."
                  value={patientHpi}
                  onChange={(e) => setPatientHpi(e.target.value)}
                  className="w-full p-3 border border-slate-200 rounded-xl text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Known Allergies</label>
                  <input
                    type="text"
                    placeholder="e.g. Penicillin, Latex"
                    value={patientAllergies}
                    onChange={(e) => setPatientAllergies(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Current Medications</label>
                  <input
                    type="text"
                    placeholder="e.g. Lisinopril, Metformin"
                    value={patientMeds}
                    onChange={(e) => setPatientMeds(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full h-11 bg-brand-600 hover:bg-brand-700 disabled:bg-slate-400 text-white font-bold rounded-xl text-sm"
              >
                {loading ? "Saving..." : "Save Patient Log"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: LOG HOURS & PROCEDURES */}
      {logModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-md w-full animate-slide-up">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-800">Record Procedure Log</h3>
              <button onClick={() => setLogModal(false)} className="text-slate-400 hover:text-slate-600 font-bold">Close</button>
            </div>

            <form onSubmit={handleCreateLog} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Procedure Name</label>
                  <select
                    value={logProcedure}
                    onChange={(e) => setLogProcedure(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm bg-white"
                  >
                    <option>IV Insertion</option>
                    <option>Medication Administration</option>
                    <option>Catheterization</option>
                    <option>Wound Dressing</option>
                    <option>Vital Signs Monitoring</option>
                    <option>Oxygen Therapy</option>
                    <option>Patient Education</option>
                    <option>Blood Sampling</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Hours spent</label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    placeholder="2.5"
                    value={logHours}
                    onChange={(e) => setLogHours(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Ward / Unit</label>
                  <input
                    type="text"
                    required
                    placeholder="ICU"
                    value={logWard}
                    onChange={(e) => setLogWard(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Date</label>
                  <input
                    type="date"
                    value={logDate}
                    onChange={(e) => setLogDate(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Clinical Supervisor</label>
                  <input
                    type="text"
                    required
                    placeholder="Sarah Jenkins, RN"
                    value={logSupervisor}
                    onChange={(e) => setLogSupervisor(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Competency level</label>
                  <select
                    value={logCompetency}
                    onChange={(e) => setLogCompetency(e.target.value)}
                    className="w-full h-10 px-3 border border-slate-200 rounded-xl text-sm bg-white"
                  >
                    <option value="supervised">Supervised</option>
                    <option value="assisted">Assisted</option>
                    <option value="independent">Independent</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Self-Reflection & Notes</label>
                <textarea
                  rows={2}
                  placeholder="Reflect on challenges faced, patient communication, and adjustments..."
                  value={logReflection}
                  onChange={(e) => setLogReflection(e.target.value)}
                  className="w-full p-3 border border-slate-200 rounded-xl text-sm"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full h-11 bg-brand-600 hover:bg-brand-700 disabled:bg-slate-400 text-white font-bold rounded-xl text-sm"
              >
                {loading ? "Recording..." : "Record Log"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
