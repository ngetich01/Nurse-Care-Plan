# Deployment Guide - NursePlan Pro

NursePlan Pro is structured as a decoupled full-stack application. Follow these instructions to deploy the platform to a production environment.

---

## 1. Prerequisites
Ensure the target server environment has:
- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher
- **PostgreSQL Database**: v14.0 or higher
- **AWS S3 Account**: For secure static clinical uploads (if enabled)

---

## 2. Environment Variables Configuration

### Backend Setup (`backend/.env`)
Create a production environment configuration file with the following variables:
```ini
PORT=5000
NODE_ENV=production
JWT_SECRET=production_long_cryptographic_random_string
MOCK_DATABASE=false
DATABASE_URL=postgresql://user:password@host:5432/nurseplan_prod
AWS_ACCESS_KEY_ID=your_key_id
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_S3_BUCKET=nurseplan-secure-bucket
```

### Frontend Setup (`frontend/.env.local`)
Configure the API endpoint of the deployed Express backend:
```ini
NEXT_PUBLIC_API_URL=https://api.nurseplanpro.com
```

---

## 3. Database Migration & Initialization
To set up the production PostgreSQL schema and seed the initial NANDA diagnoses library:
1. Connect to your PostgreSQL database.
2. Run the SQL schema:
   ```bash
   psql -h host -U user -d nurseplan_prod -f database/schema.sql
   ```
3. Seed the NANDA catalog and mock configurations:
   ```bash
   psql -h host -U user -d nurseplan_prod -f database/seed.sql
   ```

---

## 4. Backend Deployment (AWS EC2 / PM2)
Deploy the Express API server to an AWS EC2 instance or a similar Node hosting platform.

1. SSH into the production server.
2. Clone the repository and navigate to the backend folder.
3. Install production dependencies:
   ```bash
   npm ci --omit=dev
   ```
4. Build the TypeScript compilation:
   ```bash
   npm run build
   ```
5. Run the server using a process manager like PM2:
   ```bash
   pm2 start dist/server.js --name "nurseplan-backend"
   ```

---

## 5. Frontend Deployment (Vercel / AWS Amplify)
Deploy the Next.js frontend client to Vercel (recommended) or AWS Amplify.

1. Create a new project on Vercel.
2. Link the repository, setting the root directory to `frontend/`.
3. Add the `NEXT_PUBLIC_API_URL` environment variable.
4. Trigger the build and deploy. Vercel automatically configures the serverless rendering parameters.
