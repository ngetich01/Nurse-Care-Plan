# API Documentation - NursePlan Pro

The NursePlan Pro backend API exposes REST endpoints for user authentication, patient logging, care planning, clinical logbooks, and administrative settings.

---

## 1. Base URL
All requests are served from the default URL:
`http://localhost:5000/api`

---

## 2. Authentication System

### Register User
- **Endpoint**: `POST /auth/register`
- **Request Body**:
  ```json
  {
    "email": "student@nursingschool.edu",
    "password": "password123",
    "name": "John Doe",
    "role": "student",
    "enrollmentNumber": "ENR-2026-0001"
  }
  ```
- **Response**:
  ```json
  {
    "message": "Registration successful",
    "token": "JWT_TOKEN_STRING",
    "user": {
      "id": "usr-uuid-string",
      "email": "student@nursingschool.edu",
      "role": "student",
      "name": "John Doe"
    }
  }
  ```

### Login User
- **Endpoint**: `POST /auth/login`
- **Request Body**:
  ```json
  {
    "email": "student@nursingschool.edu",
    "password": "password123"
  }
  ```
- **Response (Standard)**:
  ```json
  {
    "token": "JWT_TOKEN_STRING",
    "user": {
      "id": "usr-uuid-string",
      "email": "student@nursingschool.edu",
      "role": "student",
      "name": "John Doe"
    }
  }
  ```
- **Response (MFA Enabled)**:
  ```json
  {
    "mfaRequired": true,
    "userId": "usr-uuid-string",
    "message": "Multi-factor authentication code required"
  }
  ```

---

## 3. Care Plan Management

### Create Care Plan
- **Endpoint**: `POST /careplans`
- **Headers**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "patientId": "pat-uuid-string",
    "title": "Abdominal Surgery Care Plan"
  }
  ```

### Update / Auto Save Care Plan
- **Endpoint**: `PUT /careplans/:id`
- **Headers**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "subjectiveData": "Patient complains of sharp pain.",
    "objectiveData": "BP 120/80, HR 88, SpO2 98%.",
    "nursingDiagnosis": "[{\"code\":\"00132\",\"name\":\"Acute Pain\"}]"
  }
  ```

---

## 4. AI Clinical Assistant

### Suggest Diagnoses
- **Endpoint**: `POST /ai/diagnoses`
- **Headers**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "subjectiveData": "shortness of breath",
    "objectiveData": "SpO2 91% on room air"
  }
  ```
- **Response**:
  ```json
  {
    "suggestions": [
      {
        "code": "00031",
        "name": "Ineffective Airway Clearance",
        "matchReason": "Detected indicators of airway secretions, abnormal auscultation or breathlessness."
      }
    ]
  }
  ```
