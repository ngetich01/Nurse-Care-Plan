-- Seed Data for NursePlan Pro Database

-- Pre-populate Schools
INSERT INTO schools (id, name, subscription_plan, subscription_status) VALUES
('sch-001', 'Greenfield Nursing College', 'School Premium', 'active'),
('sch-002', 'St. Jude Health Academy', 'School Standard', 'active');

-- Pre-populate Users (Mock System Administrators, Instructors, and Students)
-- Password hashes are hashed using bcrypt for "password123" ($2a$10$XOP.S09R0QoR5mR11hFwfeC0p7zJb1kU8.e6g5x4M4bJj5p5W5t2e)
INSERT INTO users (id, email, password_hash, role, name, school_id, status, email_verified) VALUES
('sys-admin', 'admin@nurseplanpro.com', '$2a$10$XOP.S09R0QoR5mR11hFwfeC0p7zJb1kU8.e6g5x4M4bJj5p5W5t2e', 'system_admin', 'System Administrator', NULL, 'active', TRUE),
('inst-001', 'sarah.jenkins@greenfield.edu', '$2a$10$XOP.S09R0QoR5mR11hFwfeC0p7zJb1kU8.e6g5x4M4bJj5p5W5t2e', 'instructor', 'Dr. Sarah Jenkins, RN', 'sch-001', 'active', TRUE),
('stud-001', 'john.doe@greenfield.edu', '$2a$10$XOP.S09R0QoR5mR11hFwfeC0p7zJb1kU8.e6g5x4M4bJj5p5W5t2e', 'student', 'John Doe', 'sch-001', 'active', TRUE),
('stud-002', 'jane.smith@greenfield.edu', '$2a$10$XOP.S09R0QoR5mR11hFwfeC0p7zJb1kU8.e6g5x4M4bJj5p5W5t2e', 'student', 'Jane Smith', 'sch-001', 'active', TRUE);

-- Insert roles metadata
INSERT INTO students (id, enrollment_number, graduation_date, clinical_hours_logged, clinical_hours_approved) VALUES
('stud-001', 'ENR-2026-0001', '2027-05-15', 12.0, 8.0),
('stud-002', 'ENR-2026-0002', '2027-05-15', 6.0, 0.0);

INSERT INTO instructors (id, employee_id, department) VALUES
('inst-001', 'EMP-7712', 'Medical-Surgical Nursing');

-- Pre-populate NANDA Nursing Diagnoses Library
INSERT INTO diagnoses (id, code, name, definition, related_factors, risk_factors, signs_symptoms, default_goals, default_interventions, default_rationales, category, reference_info) VALUES
(
    'diag-001',
    '00132',
    'Acute Pain',
    'Unpleasant sensory and emotional experience associated with actual or potential tissue damage, or described in terms of such damage; sudden or slow onset of any intensity from mild to severe with an anticipated or predictable end.',
    'Biological injury agent (e.g., infection, ischemia, neoplasm), Chemical injury agent (e.g., burn, acid), Physical injury agent (e.g., abscess, amputation, cut, trauma, surgical procedure).',
    NULL,
    'Alteration in muscle tone, autonomic behavior, expressive behavior (e.g., restlessness, crying, vigilance), protective behavior, distraction behavior, self-focused, report of pain, facial expression of pain.',
    '["Patient will report a decrease in pain level from 8/10 to 3/10 within 2 hours of initiating analgesic therapy.","Patient will demonstrate using non-pharmacological pain management techniques (e.g., deep breathing) within 24 hours."]',
    '["Assess pain characteristics: location, quality, severity (0-10 scale), and triggers every 4 hours.","Administer ordered analgesics as prescribed and evaluate effectiveness 30-60 minutes post-administration.","Position patient in optimal body alignment to reduce muscle tension and pressure on surgical site.","Teach patient and family non-pharmacological pain management strategies, including guided imagery and relaxation."]',
    '["Frequent assessments ensure timely treatment adjustment and baseline tracking.","Evaluation of analgesics verifies therapeutic response and helps identify adverse effects.","Proper alignment minimizes stress on injured tissues and promotes muscle relaxation.","Non-pharmacological strategies complement medication and empower patient self-care."]',
    'Neurological',
    'NANDA International Nursing Diagnoses: Definitions & Classification 2021-2023.'
),
(
    'diag-002',
    '00004',
    'Risk for Infection',
    'Vulnerable to invasion and multiplication of pathogenic organisms, which may compromise health.',
    NULL,
    'Chronic illness, inadequate primary defenses (e.g., broken skin, tissue trauma), invasive procedures (e.g., IV line, urinary catheter), malnutrition, pharmaceutical agents (e.g., immunosuppressants).',
    NULL,
    '["Patient will remain free from signs and symptoms of systemic or localized infection (e.g., no fever, wound purulence, or erythema) throughout hospitalization.","Patient and caregivers will demonstrate correct hand hygiene techniques before leaving the facility."]',
    '["Perform hand hygiene before and after all patient contacts and invasive procedures.","Monitor vital signs, especially temperature and heart rate, every 4 hours.","Inspect invasive line sites (e.g., IV catheter) and surgical wounds daily for redness, swelling, warmth, or drainage.","Maintain aseptic technique during wound care, dressing changes, and catheter management."]',
    '["Hand hygiene is the single most effective measure to prevent healthcare-associated infections.","Fever and tachycardia are early systemic indicators of infectious processes.","Local signs of infection allow early detection and localized intervention before dissemination.","Asepsis prevents the introduction of environmental pathogens into vulnerable tissues."]',
    'Renal',
    'Ackley, B. J., & Ladwig, G. B. (2020). Nursing Diagnosis Handbook: An Evidence-Based Guide to Planning Care.'
),
(
    'diag-003',
    '00031',
    'Ineffective Airway Clearance',
    'Inability to clear secretions or obstructions from the respiratory tract to maintain a clear airway.',
    'Airway spasm, retained secretions, excessive mucus, foreign body in airway, neuromuscular impairment, smoking.',
    NULL,
    'Absent or ineffective cough, adventitious breath sounds (crackles, wheezing), dyspnea, excessive sputum, cyanosis, change in respiratory rate or rhythm.',
    '["Patient will maintain a patent airway as evidenced by clear breath sounds and respiratory rate within normal limits (12-20 breaths/min) within 12 hours.","Patient will demonstrate effective coughing and deep-breathing techniques."]',
    '["Auscultate breath sounds every 2 to 4 hours to assess for airway obstruction and fluid accumulation.","Position patient in high-Fowler''s position (60-90 degrees) to maximize lung expansion.","Encourage fluid intake up to 2.5 liters per day (unless contraindicated) to thin secretions.","Instruct patient in the controlled coughing technique (huff cough) and deep-breathing exercises."]',
    '["Adventitious sounds like wheezing or crackles indicate specific patterns of airway obstruction.","Fowler''s position uses gravity to lower the diaphragm, facilitating greater chest expansion and coughing power.","Adequate hydration thins pulmonary secretions, making them easier to expectorate.","Controlled coughing helps clear secretions from the lower airways without causing excessive exhaustion."]',
    'Respiratory',
    'Doenges, M. E., Moorhouse, M. F., & Murr, A. C. (2019). Nurse''s Pocket Guide: Diagnoses, Prioritized Interventions, and Rationales.'
),
(
    'diag-004',
    '00085',
    'Impaired Physical Mobility',
    'Limitation in independent, purposeful physical movement of the body or of one or more extremities.',
    'Decreased muscle strength, joint stiffness, pain, neuromuscular impairment, prescribed activity restrictions (e.g., bed rest), cognitive impairment.',
    NULL,
    'Difficulty turning, slow movement, postural instability, decreased range of motion, uncoordinated movements.',
    '["Patient will perform active or passive range of motion exercises at least 3 times daily.","Patient will mobilize to the bedside chair with assistance of one helper twice daily."]',
    '["Assess baseline mobility level, balance, and muscle strength prior to transfer attempts.","Perform range-of-motion (ROM) exercises to joints twice daily, active or passive.","Assist and teach patient proper use of assistive devices (e.g., walker, cane) during ambulation.","Turn and reposition patient every 2 hours while in bed to prevent skin breakdown."]',
    '["Assessment prevents falls and matches activity level to physiological tolerance.","ROM exercises maintain joint mobility, prevent contractures, and stimulate circulation.","Assistive devices promote independence while securing patient safety.","Repositioning relieves pressure over bony prominences, preserving skin integrity."]',
    'Musculoskeletal',
    'Herdman, T. H., & Kamitsuru, S. (2018). NANDA International Nursing Diagnoses: Definitions & Classification.'
),
(
    'diag-005',
    '00146',
    'Anxiety',
    'Vague, uneasy feeling of discomfort or dread accompanied by an autonomic response; the source is often nonspecific or unknown to the individual; a feeling of apprehension caused by anticipation of danger.',
    'Threat to self-concept, threat of death, status change, physiological factors (e.g., hypoxia, pain), situational crisis, unmet needs.',
    NULL,
    'Apprehension, nervousness, helplessness, increased tension, voice tremors, trembling, tachypnea, tachycardia, pupillary dilation, insomnia.',
    '["Patient will verbalize a reduction in anxiety level from severe to mild within 4 hours.","Patient will identify three coping mechanisms to manage anxiety when symptoms arise."]',
    '["Assess patient''s level of anxiety (mild, moderate, severe, panic) and vital signs.","Provide a calm, quiet environment with reduced sensory stimuli (dim lights, quiet room).","Explain all procedures, healthcare plans, and diagnostic tests in simple, clear terms.","Teach the patient slow, diaphragmatic breathing and relaxation exercises."]',
    '["Understanding the level of anxiety helps determine if the patient can comprehend instructions.","Sensory overload exacerbates physiological stress responses.","Clear explanations alleviate fear of the unknown and build therapeutic trust.","Diaphragmatic breathing stimulates the parasympathetic nervous system, lowering heart rate and promoting calm."]',
    'Mental Health',
    'NANDA International Nursing Diagnoses: Definitions & Classification 2021-2023.'
);
