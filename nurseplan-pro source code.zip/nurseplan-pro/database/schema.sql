-- Database Schema for NursePlan Pro (PostgreSQL)

-- Drop tables if they exist
DROP TABLE IF EXISTS audit_logs CASCADE;
DROP TABLE IF EXISTS notifications CASCADE;
DROP TABLE IF EXISTS grades CASCADE;
DROP TABLE IF EXISTS clinical_logs CASCADE;
DROP TABLE IF EXISTS care_plans CASCADE;
DROP TABLE IF EXISTS diagnoses CASCADE;
DROP TABLE IF EXISTS patients CASCADE;
DROP TABLE IF EXISTS instructors CASCADE;
DROP TABLE IF EXISTS students CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS schools CASCADE;

-- 1. Schools Table
CREATE TABLE schools (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    subscription_plan VARCHAR(50) DEFAULT 'Student Free',
    subscription_status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Users Table (Authentication and core profiles)
CREATE TABLE users (
    id VARCHAR(36) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('student', 'instructor', 'school_admin', 'system_admin')),
    name VARCHAR(255) NOT NULL,
    school_id VARCHAR(36) REFERENCES schools(id) ON DELETE SET NULL,
    status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'pending', 'suspended')),
    mfa_secret VARCHAR(255),
    mfa_enabled BOOLEAN DEFAULT FALSE,
    email_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Students Table (Role-specific extension)
CREATE TABLE students (
    id VARCHAR(36) PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    enrollment_number VARCHAR(100),
    graduation_date DATE,
    clinical_hours_logged NUMERIC(6, 2) DEFAULT 0.0,
    clinical_hours_approved NUMERIC(6, 2) DEFAULT 0.0
);

-- 4. Instructors Table (Role-specific extension)
CREATE TABLE instructors (
    id VARCHAR(36) PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    employee_id VARCHAR(100),
    department VARCHAR(255)
);

-- 5. Patients Table (HIPAA-compliant, using initials only)
CREATE TABLE patients (
    id VARCHAR(36) PRIMARY KEY,
    initials VARCHAR(10) NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(50) NOT NULL,
    ward VARCHAR(100) NOT NULL,
    bed_number VARCHAR(50) NOT NULL,
    admission_date DATE NOT NULL,
    medical_diagnosis VARCHAR(255) NOT NULL,
    history_of_present_illness TEXT,
    allergies TEXT,
    current_medications TEXT,
    notes TEXT,
    student_id VARCHAR(36) REFERENCES students(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. Diagnoses Library Table
CREATE TABLE diagnoses (
    id VARCHAR(36) PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    definition TEXT NOT NULL,
    related_factors TEXT,
    risk_factors TEXT,
    signs_symptoms TEXT,
    default_goals TEXT,          -- JSON string or text representation
    default_interventions TEXT,  -- JSON string or text representation
    default_rationales TEXT,     -- JSON string or text representation
    category VARCHAR(100) NOT NULL,
    reference_info TEXT,         -- Rename from 'references' to avoid keyword conflicts
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. Care Plans Table
CREATE TABLE care_plans (
    id VARCHAR(36) PRIMARY KEY,
    patient_id VARCHAR(36) REFERENCES patients(id) ON DELETE CASCADE,
    student_id VARCHAR(36) REFERENCES students(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'draft' CHECK (status IN ('draft', 'submitted', 'reviewed', 'revision_requested')),
    subjective_data TEXT,        -- Patient complaints, history, symptoms
    objective_data TEXT,         -- Vitals, physical exam, labs, diagnostics
    nursing_diagnosis TEXT,      -- JSON list of diagnoses or text
    short_term_goals TEXT,       -- SMART goals
    long_term_goals TEXT,        -- SMART goals
    interventions TEXT,          -- Planned nursing interventions (with rationales)
    implementation_notes TEXT,   -- Record of interventions performed
    evaluation_status VARCHAR(50) CHECK (evaluation_status IN ('met', 'partially_met', 'not_met', NULL)),
    evaluation_notes TEXT,       -- Evaluation reflection
    revision_notes TEXT,         -- Revision comments from instructor
    grade NUMERIC(4, 2),         -- Total score out of 50
    instructor_feedback TEXT,    -- General comments
    submitted_at TIMESTAMP,
    graded_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. Clinical Logs Table
CREATE TABLE clinical_logs (
    id VARCHAR(36) PRIMARY KEY,
    student_id VARCHAR(36) REFERENCES students(id) ON DELETE CASCADE,
    procedure_name VARCHAR(255) NOT NULL,
    date DATE NOT NULL,
    ward VARCHAR(100) NOT NULL,
    supervisor_name VARCHAR(255) NOT NULL,
    reflection_notes TEXT,
    competency_status VARCHAR(50) NOT NULL CHECK (competency_status IN ('supervised', 'assisted', 'independent')),
    hours NUMERIC(4, 2) NOT NULL,
    approved_by_id VARCHAR(36) REFERENCES instructors(id) ON DELETE SET NULL,
    approval_status VARCHAR(50) DEFAULT 'pending' CHECK (approval_status IN ('pending', 'approved', 'rejected')),
    approved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 9. Grades Table (Rubric details)
CREATE TABLE grades (
    id VARCHAR(36) PRIMARY KEY,
    care_plan_id VARCHAR(36) UNIQUE REFERENCES care_plans(id) ON DELETE CASCADE,
    instructor_id VARCHAR(36) REFERENCES instructors(id) ON DELETE SET NULL,
    assessment_score NUMERIC(4, 2) DEFAULT 0.0 CHECK (assessment_score >= 0 AND assessment_score <= 10),
    diagnosis_score NUMERIC(4, 2) DEFAULT 0.0 CHECK (diagnosis_score >= 0 AND diagnosis_score <= 10),
    goals_score NUMERIC(4, 2) DEFAULT 0.0 CHECK (goals_score >= 0 AND goals_score <= 10),
    interventions_score NUMERIC(4, 2) DEFAULT 0.0 CHECK (interventions_score >= 0 AND interventions_score <= 10),
    evaluation_score NUMERIC(4, 2) DEFAULT 0.0 CHECK (evaluation_score >= 0 AND evaluation_score <= 10),
    total_score NUMERIC(4, 2) DEFAULT 0.0 CHECK (total_score >= 0 AND total_score <= 50),
    feedback TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 10. Notifications Table
CREATE TABLE notifications (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    read BOOLEAN DEFAULT FALSE,
    type VARCHAR(50) DEFAULT 'general',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 11. Audit Logs Table (For GDPR compliance & Security)
CREATE TABLE audit_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45),
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
