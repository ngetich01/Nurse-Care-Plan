# Testing Plan - NursePlan Pro

This document outlines the testing strategy to verify the NursePlan Pro clinical Care Planning platform.

---

## 1. Test Environments
- **Local Dev**: SQLite database wrapper, simulated AI generator.
- **Staging / QA**: AWS RDS PostgreSQL database, real LLM suggestion API integration.

---

## 2. Unit Testing Strategy

### Backend REST API
Run validation tests on all core controllers using a separate test database (or SQLite memory configuration):
- **Authentication**: Verify registration, login credentials validation, and MFA validation filters.
- **RBAC Filters**: Test endpoints with invalid roles (e.g. verify student accounts cannot access admin analytics or instructor grading routes).
- **Quality Audit Reviewer**: Run test assessments through the AI auditor and check if quality index scores match standard criteria.

---

## 3. End-to-End User Flow Tests

### Flow A: The Student Process
1. Register a new student user.
2. Log a new patient initials record (e.g., `M.K.`, Age `54`, Ward `ICU`).
3. Open the Care Plan Builder and fill out Step 1 (Subjective/Objective assessments).
4. Run AI suggestions, attach `00031 Ineffective Airway Clearance` NANDA diagnosis.
5. Generate SMART goals, add planned interventions with rationales.
6. Verify auto-save updates state.
7. Click "Submit Assignment".

### Flow B: The Instructor Process
1. Log in as an instructor.
2. Verify the submitted care plan is visible in the Assignment inbox.
3. Review patient details and assessment fields.
4. Input grading marks out of 10 for each of the 5 sections (Assessment, Diagnosis, Goals, Interventions, Evaluation).
5. Add general feedback notes, click "Submit Grade".
6. Verify student notifications are pushed.

### Flow C: Clinical log approval
1. Student logs a procedure (e.g. `IV Insertion`, `2 hours`).
2. Instructor verifies logs inside the approval inbox, clicks "Approve".
3. Check student dashboard stats: total approved hours should increment by `2`.
