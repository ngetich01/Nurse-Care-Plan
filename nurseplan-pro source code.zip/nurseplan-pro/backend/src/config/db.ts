import { Pool } from 'pg';
import sqlite3 from 'sqlite3';
import fs from 'fs';
import path from 'path';

let pgPool: Pool | null = null;
let sqliteDb: sqlite3.Database | null = null;
const useSqlite = process.env.MOCK_DATABASE === 'true' || !process.env.DATABASE_URL;

export async function initDb() {
  if (useSqlite) {
    const dbDir = path.resolve(__dirname, '../../../database');
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }
    const dbPath = path.join(dbDir, 'local.db');
    const isNew = !fs.existsSync(dbPath);

    sqliteDb = new sqlite3.Database(dbPath);

    if (isNew) {
      console.log('Initializing a new SQLite local database for local development...');
      try {
        const schemaPath = path.join(dbDir, 'schema.sql');
        const seedPath = path.join(dbDir, 'seed.sql');

        if (fs.existsSync(schemaPath)) {
          const schema = fs.readFileSync(schemaPath, 'utf8');
          // SQLite doesn't support running multiple statements separated by semicolons in one go easily via run,
          // so we split by semicolon and run each non-empty line.
          await execMultipleStatementsSqlite(schema);
        }

        if (fs.existsSync(seedPath)) {
          const seed = fs.readFileSync(seedPath, 'utf8');
          await execMultipleStatementsSqlite(seed);
        }
        console.log('SQLite database initialized and seeded successfully.');
      } catch (err) {
        console.error('Error seeding SQLite database:', err);
      }
    } else {
      console.log('Using existing SQLite local database.');
    }
  } else {
    console.log('Using PostgreSQL database.');
    pgPool = new Pool({
      connectionString: process.env.DATABASE_URL,
    });
  }
}

// Helper to run multiline SQL files in SQLite
function execMultipleStatementsSqlite(sqlText: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!sqliteDb) return reject(new Error('SQLite not initialized'));
    
    // Simple parser to separate commands. Semicolons inside quotes can be problematic, 
    // but this basic parser works for our schema and seed.
    // Also remove comments.
    const cleanSql = sqlText
      .replace(/--.*$/gm, '') // remove line comments
      .replace(/\/\*[\s\S]*?\*\//g, ''); // remove block comments

    // Split by semicolons, ignoring semicolons inside strings
    const statements: string[] = [];
    let current = '';
    let inString = false;
    let stringChar = '';

    for (let i = 0; i < cleanSql.length; i++) {
      const char = cleanSql[i];
      if ((char === "'" || char === '"') && cleanSql[i - 1] !== '\\') {
        if (!inString) {
          inString = true;
          stringChar = char;
        } else if (char === stringChar) {
          inString = false;
        }
      }
      if (char === ';' && !inString) {
        statements.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    if (current.trim()) {
      statements.push(current.trim());
    }

    sqliteDb.serialize(() => {
      sqliteDb?.run('BEGIN TRANSACTION', (err) => {
        if (err) return reject(err);
      });

      let errorOccurred = false;
      for (const statement of statements) {
        if (!statement) continue;
        sqliteDb?.run(statement, (err) => {
          if (err) {
            console.error('Error running statement:', statement, err);
            errorOccurred = true;
          }
        });
      }

      sqliteDb?.run(errorOccurred ? 'ROLLBACK' : 'COMMIT', (err) => {
        if (err || errorOccurred) {
          reject(err || new Error('Transaction aborted due to syntax errors'));
        } else {
          resolve();
        }
      });
    });
  });
}

// Unified Query interface
export function query(text: string, params: any[] = []): Promise<{ rows: any[] }> {
  return new Promise((resolve, reject) => {
    if (useSqlite) {
      if (!sqliteDb) {
        return reject(new Error('SQLite Database is not initialized. Call initDb() first.'));
      }
      
      // Convert postgres parameterized syntax ($1, $2) to sqlite syntax (?, ?)
      let sqliteText = text;
      // We must match $1, $2, etc. and replace with ?
      // Safe replacement as long as text doesn't contain $ inside strings (none in our endpoints)
      sqliteText = sqliteText.replace(/\$\d+/g, '?');

      // Check query type to decide run vs all
      const isSelect = sqliteText.trim().toUpperCase().startsWith('SELECT') || 
                      sqliteText.trim().toUpperCase().startsWith('WITH');

      if (isSelect) {
        sqliteDb.all(sqliteText, params, (err, rows) => {
          if (err) return reject(err);
          resolve({ rows });
        });
      } else {
        sqliteDb.run(sqliteText, params, function (err) {
          if (err) return reject(err);
          // Return an emulation of pg response format
          // SQLite run doesn't return rows, but sometimes we need the inserted id or changes.
          // We can return rows with the lastID if requested.
          resolve({ rows: [{ id: (this as any).lastID, changes: this.changes }] });
        });
      }
    } else {
      if (!pgPool) {
        return reject(new Error('PostgreSQL Pool is not initialized. Call initDb() first.'));
      }
      pgPool.query(text, params)
        .then((res) => resolve({ rows: res.rows }))
        .catch((err) => reject(err));
    }
  });
}
