import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import path from 'path';

// Load Environment Variables
dotenv.config({ path: path.resolve(__dirname, '../.env') });

import { initDb } from './config/db';
import { authenticateToken } from './middleware/auth';
import {
  register,
  login,
  verifyMfa,
  setupMfa,
  resetPassword,
  getProfile
} from './controllers/auth';
import {
  createPatient,
  getPatients,
  createCarePlan,
  getCarePlans,
  getCarePlanById,
  updateCarePlan,
  submitCarePlan,
  gradeCarePlan,
  getDiagnoses,
  getDiagnosisById
} from './controllers/careplan';
import {
  suggestDiagnoses,
  generateGoals,
  generateInterventions,
  reviewCarePlan
} from './controllers/ai';
import {
  createClinicalLog,
  getClinicalLogs,
  approveClinicalLog
} from './controllers/clinical';
import {
  getUsers,
  updateUserStatus,
  getSchools,
  updateSchoolSubscription,
  getAnalytics
} from './controllers/admin';
import {
  getNotifications,
  markNotificationRead
} from './controllers/notifications';

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(helmet());
app.use(cors({
  origin: '*', // Allow all client queries in local dev setup
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

// 1. Health check route
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'NursePlan Pro API Server', timestamp: new Date() });
});

// 2. Authentication API endpoints
app.post('/api/auth/register', register);
app.post('/api/auth/login', login);
app.post('/api/auth/mfa/verify', verifyMfa);
app.post('/api/auth/mfa/setup', authenticateToken, setupMfa);
app.post('/api/auth/reset-password', resetPassword);
app.get('/api/auth/profile', authenticateToken, getProfile);

// 3. HIPAA Patient Profiles
app.post('/api/patients', authenticateToken, createPatient);
app.get('/api/patients', authenticateToken, getPatients);

// 4. Care Plans Processes
app.post('/api/careplans', authenticateToken, createCarePlan);
app.get('/api/careplans', authenticateToken, getCarePlans);
app.get('/api/careplans/:id', authenticateToken, getCarePlanById);
app.put('/api/careplans/:id', authenticateToken, updateCarePlan);
app.post('/api/careplans/:id/submit', authenticateToken, submitCarePlan);
app.post('/api/careplans/:id/grade', authenticateToken, gradeCarePlan);

// 5. NANDA Diagnoses Library Catalog
app.get('/api/diagnoses', getDiagnoses);
app.get('/api/diagnoses/:id', getDiagnosisById);

// 6. Clinical Logbook Module
app.post('/api/clinical-logs', authenticateToken, createClinicalLog);
app.get('/api/clinical-logs', authenticateToken, getClinicalLogs);
app.post('/api/clinical-logs/:id/approve', authenticateToken, approveClinicalLog);

// 7. Simulated AI Coprocessor API
app.post('/api/ai/diagnoses', authenticateToken, suggestDiagnoses);
app.post('/api/ai/goals', authenticateToken, generateGoals);
app.post('/api/ai/interventions', authenticateToken, generateInterventions);
app.post('/api/ai/review', authenticateToken, reviewCarePlan);

// 8. User & Subscription Administrative endpoints
app.get('/api/admin/users', authenticateToken, getUsers);
app.put('/api/admin/users/:id/status', authenticateToken, updateUserStatus);
app.get('/api/admin/schools', authenticateToken, getSchools);
app.put('/api/admin/schools/:id/subscription', authenticateToken, updateSchoolSubscription);
app.get('/api/admin/analytics', authenticateToken, getAnalytics);

// 9. Alerting / Notification endpoints
app.get('/api/notifications', authenticateToken, getNotifications);
app.put('/api/notifications/:id/read', authenticateToken, markNotificationRead);

// Error Handling Middleware
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Express Error Handler:', err);
  res.status(500).json({ error: 'Server Internal Error: Express core failure.' });
});

// Initialize database and start Server
async function startServer() {
  try {
    await initDb();
    app.listen(PORT, () => {
      console.log(`[NursePlan Pro Backend Server] Running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Database connection failed. Server failed to start:', error);
    process.exit(1);
  }
}

startServer();
