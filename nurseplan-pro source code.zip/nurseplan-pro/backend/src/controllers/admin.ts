import { Response } from 'express';
import { query } from '../config/db';
import { AuthenticatedRequest } from '../middleware/auth';

// 1. User Management (School Admin or System Admin)
export async function getUsers(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

    let result;
    if (req.user.role === 'system_admin') {
      result = await query(
        `SELECT u.id, u.email, u.role, u.name, u.status, u.email_verified, u.created_at, s.name as school_name 
         FROM users u LEFT JOIN schools s ON u.school_id = s.id ORDER BY u.created_at DESC`
      );
    } else if (req.user.role === 'school_admin') {
      result = await query(
        `SELECT id, email, role, name, status, email_verified, created_at 
         FROM users WHERE school_id = $1 ORDER BY created_at DESC`,
        [req.user.schoolId]
      );
    } else {
      return res.status(403).json({ error: 'Access denied: Administration rights required.' });
    }

    return res.json(result.rows);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to retrieve system users' });
  }
}

export async function updateUserStatus(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user || (req.user.role !== 'school_admin' && req.user.role !== 'system_admin')) {
      return res.status(403).json({ error: 'Administration permission required' });
    }

    const { id } = req.params;
    const { status, emailVerified } = req.body; // status: active, suspended

    // Retrieve user's school to verify school admin permissions
    const userCheck = await query('SELECT school_id, role FROM users WHERE id = $1', [id]);
    if (userCheck.rows.length === 0) return res.status(404).json({ error: 'User not found' });

    if (req.user.role === 'school_admin' && userCheck.rows[0].school_id !== req.user.schoolId) {
      return res.status(403).json({ error: 'Cannot manage users from another school' });
    }

    await query(
      'UPDATE users SET status = COALESCE($1, status), email_verified = COALESCE($2, email_verified) WHERE id = $3',
      [status, emailVerified, id]
    );

    return res.json({ message: 'User updated successfully' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update user parameters' });
  }
}

// 2. School / Subscription Management
export async function getSchools(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user || req.user.role !== 'system_admin') {
      return res.status(403).json({ error: 'System administrator permissions required' });
    }
    const result = await query('SELECT * FROM schools ORDER BY name ASC');
    return res.json(result.rows);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to query schools list' });
  }
}

export async function updateSchoolSubscription(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user || req.user.role !== 'system_admin') {
      return res.status(403).json({ error: 'System administrator permissions required' });
    }

    const { id } = req.params;
    const { subscriptionPlan, subscriptionStatus } = req.body; // active, suspended, expired

    await query(
      'UPDATE schools SET subscription_plan = COALESCE($1, subscription_plan), subscription_status = COALESCE($2, subscription_status) WHERE id = $3',
      [subscriptionPlan, subscriptionStatus, id]
    );

    return res.json({ message: 'School subscription updated successfully' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update school subscription status' });
  }
}

// 3. School Admin / System Admin Analytics
export async function getAnalytics(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user || (req.user.role !== 'school_admin' && req.user.role !== 'system_admin')) {
      return res.status(403).json({ error: 'Unauthorized access' });
    }

    const schoolId = req.user.schoolId;

    // A. Student counts & stats
    const studentCountResult = await query(
      `SELECT COUNT(*) as count FROM users WHERE role = 'student' AND ($1::varchar IS NULL OR school_id = $1)`,
      [schoolId]
    );
    const instructorCountResult = await query(
      `SELECT COUNT(*) as count FROM users WHERE role = 'instructor' AND ($1::varchar IS NULL OR school_id = $1)`,
      [schoolId]
    );
    
    // B. Average grades
    const gradesResult = await query(
      `SELECT AVG(grade) as average_grade, COUNT(*) as graded_count 
       FROM care_plans cp 
       JOIN users u ON cp.student_id = u.id 
       WHERE cp.status = 'reviewed' AND ($1::varchar IS NULL OR u.school_id = $1)`,
      [schoolId]
    );

    // C. Clinical hours logged vs approved
    const hoursResult = await query(
      `SELECT SUM(s.clinical_hours_logged) as total_logged, SUM(s.clinical_hours_approved) as total_approved 
       FROM students s 
       JOIN users u ON s.id = u.id 
       WHERE ($1::varchar IS NULL OR u.school_id = $1)`,
      [schoolId]
    );

    // D. Procedure counts by category
    const procedureResult = await query(
      `SELECT cl.procedure_name, COUNT(*) as count 
       FROM clinical_logs cl 
       JOIN users u ON cl.student_id = u.id 
       WHERE ($1::varchar IS NULL OR u.school_id = $1)
       GROUP BY cl.procedure_name ORDER BY count DESC LIMIT 5`,
      [schoolId]
    );

    return res.json({
      students: parseInt(studentCountResult.rows[0].count),
      instructors: parseInt(instructorCountResult.rows[0].count),
      averageGrade: parseFloat(gradesResult.rows[0].average_grade || '0').toFixed(1),
      gradedPlansCount: parseInt(gradesResult.rows[0].graded_count || '0'),
      totalClinicalHoursLogged: parseFloat(hoursResult.rows[0].total_logged || '0').toFixed(1),
      totalClinicalHoursApproved: parseFloat(hoursResult.rows[0].total_approved || '0').toFixed(1),
      proceduresSummary: procedureResult.rows
    });
  } catch (err) {
    console.error('Analytics Query Error:', err);
    return res.status(500).json({ error: 'Failed to retrieve analytics metrics' });
  }
}
