import { Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../config/db';
import { AuthenticatedRequest } from '../middleware/auth';

const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_nurseplan_token_key_2026';

// Register User (Student, Instructor, or School Administrator)
export async function register(req: AuthenticatedRequest, res: Response) {
  try {
    const { email, password, name, role, schoolName, schoolId, enrollmentNumber, employeeId, department } = req.body;

    if (!email || !password || !name || !role) {
      return res.status(400).json({ error: 'Missing required registration fields' });
    }

    // Check if user already exists
    const existingUser = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase().trim()]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // Determine school association
    let assignedSchoolId = schoolId || null;

    // If role is school_admin and a schoolName is provided, we register a new school
    if (role === 'school_admin' && schoolName) {
      const newSchoolId = `sch-${uuidv4().substring(0, 8)}`;
      await query(
        'INSERT INTO schools (id, name, subscription_plan, subscription_status) VALUES ($1, $2, $3, $4)',
        [newSchoolId, schoolName, 'School Standard', 'active']
      );
      assignedSchoolId = newSchoolId;
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);
    const userId = uuidv4();

    // Insert user
    await query(
      'INSERT INTO users (id, email, password_hash, role, name, school_id, status, email_verified) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)',
      [userId, email.toLowerCase().trim(), passwordHash, role, name, assignedSchoolId, 'active', false]
    );

    // Insert role-specific profile data
    if (role === 'student') {
      await query(
        'INSERT INTO students (id, enrollment_number, graduation_date, clinical_hours_logged, clinical_hours_approved) VALUES ($1, $2, $3, $4, $5)',
        [userId, enrollmentNumber || null, null, 0.0, 0.0]
      );
    } else if (role === 'instructor') {
      await query(
        'INSERT INTO instructors (id, employee_id, department) VALUES ($1, $2, $3)',
        [userId, employeeId || null, department || null]
      );
    }

    // Generate token
    const token = jwt.sign({ id: userId, email, role, schoolId: assignedSchoolId }, JWT_SECRET, { expiresIn: '24h' });

    // Send mock verification notification
    await query(
      'INSERT INTO notifications (id, user_id, title, message, type) VALUES ($1, $2, $3, $4, $5)',
      [uuidv4(), userId, 'Welcome to NursePlan Pro', 'Please verify your email to unlock all features.', 'general']
    );

    return res.status(201).json({
      message: 'Registration successful',
      token,
      user: { id: userId, email, role, name, schoolId: assignedSchoolId }
    });
  } catch (err: any) {
    console.error('Registration Error:', err);
    return res.status(500).json({ error: 'Internal Server Error during registration' });
  }
}

// Login User
export async function login(req: AuthenticatedRequest, res: Response) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const userResult = await query(
      'SELECT id, email, password_hash, role, name, school_id, status, mfa_enabled, mfa_secret FROM users WHERE email = $1',
      [email.toLowerCase().trim()]
    );

    if (userResult.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = userResult.rows[0];

    if (user.status === 'suspended') {
      return res.status(403).json({ error: 'Your account has been suspended. Please contact your school administrator.' });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Handle MFA
    if (user.mfa_enabled) {
      return res.json({
        mfaRequired: true,
        userId: user.id,
        message: 'Multi-factor authentication code required'
      });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, schoolId: user.school_id },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    // Write audit log
    await query(
      'INSERT INTO audit_logs (id, user_id, action, ip_address, details) VALUES ($1, $2, $3, $4, $5)',
      [uuidv4(), user.id, 'User Login', req.ip, `Logged in successfully with role ${user.role}`]
    );

    return res.json({
      token,
      user: { id: user.id, email: user.email, role: user.role, name: user.name, schoolId: user.school_id }
    });
  } catch (err) {
    console.error('Login Error:', err);
    return res.status(500).json({ error: 'Internal Server Error during login' });
  }
}

// Mock Verify MFA Code
export async function verifyMfa(req: AuthenticatedRequest, res: Response) {
  try {
    const { userId, code } = req.body;
    if (!userId || !code) {
      return res.status(400).json({ error: 'User ID and authentication code are required' });
    }

    const userResult = await query(
      'SELECT id, email, role, name, school_id, mfa_secret FROM users WHERE id = $1',
      [userId]
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = userResult.rows[0];

    // For mock code authentication, we accept any 6-digit code or '123456'
    if (code !== '123456' && code.length !== 6) {
      return res.status(400).json({ error: 'Invalid MFA verification code' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, schoolId: user.school_id },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    return res.json({
      token,
      user: { id: user.id, email: user.email, role: user.role, name: user.name, schoolId: user.school_id }
    });
  } catch (err) {
    return res.status(500).json({ error: 'MFA verification failed' });
  }
}

// Enable MFA Setup
export async function setupMfa(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

    const secret = Math.random().toString(36).substring(2, 12).toUpperCase(); // mock secret key
    await query('UPDATE users SET mfa_secret = $1, mfa_enabled = TRUE WHERE id = $2', [secret, req.user.id]);

    return res.json({
      message: 'MFA enabled successfully',
      secret,
      qrCodeUrl: `otpauth://totp/NursePlanPro:${req.user.email}?secret=${secret}&issuer=NursePlanPro`
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to configure MFA' });
  }
}

// Reset Password request
export async function resetPassword(req: AuthenticatedRequest, res: Response) {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required' });

    const userResult = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase().trim()]);
    if (userResult.rows.length === 0) {
      // Return 200 for security to avoid user enumeration
      return res.json({ message: 'If this email exists in our system, a reset link has been sent.' });
    }

    return res.json({ message: 'If this email exists in our system, a reset link has been sent.' });
  } catch (err) {
    return res.status(500).json({ error: 'Reset password request failed' });
  }
}

// Get user profile
export async function getProfile(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

    const userResult = await query(
      'SELECT u.id, u.email, u.role, u.name, u.school_id, s.name as school_name, u.mfa_enabled, u.email_verified FROM users u LEFT JOIN schools s ON u.school_id = s.id WHERE u.id = $1',
      [req.user.id]
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = userResult.rows[0];

    // Merge role profiles
    if (user.role === 'student') {
      const studentProfile = await query('SELECT * FROM students WHERE id = $1', [user.id]);
      return res.json({ ...user, profile: studentProfile.rows[0] });
    } else if (user.role === 'instructor') {
      const instructorProfile = await query('SELECT * FROM instructors WHERE id = $1', [user.id]);
      return res.json({ ...user, profile: instructorProfile.rows[0] });
    }

    return res.json(user);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to retrieve profile' });
  }
}
