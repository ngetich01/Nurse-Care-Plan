import { Response } from 'express';
import { query } from '../config/db';
import { AuthenticatedRequest } from '../middleware/auth';

// Suggest Nursing Diagnoses from subjective/objective details
export async function suggestDiagnoses(req: AuthenticatedRequest, res: Response) {
  try {
    const { subjectiveData, objectiveData } = req.body;
    if (!subjectiveData && !objectiveData) {
      return res.status(400).json({ error: 'Assessment data is required to suggest diagnoses' });
    }

    const text = `${subjectiveData} ${objectiveData}`.toLowerCase();
    
    // Query library
    const libraryResult = await query('SELECT * FROM diagnoses');
    const diagnoses = libraryResult.rows;

    const suggestions = [];

    // Basic clinical term mapping matcher
    if (text.includes('pain') || text.includes('hurt') || text.includes('ache') || text.includes('score') || text.includes('surgical')) {
      const diag = diagnoses.find(d => d.code === '00132'); // Acute Pain
      if (diag) suggestions.push({ ...diag, matchReason: 'Detected indicators of tissue discomfort/surgical trauma.' });
    }
    if (text.includes('breath') || text.includes('cough') || text.includes('sputum') || text.includes('wheez') || text.includes('sob') || text.includes('crackles')) {
      const diag = diagnoses.find(d => d.code === '00031'); // Ineffective Airway Clearance
      if (diag) suggestions.push({ ...diag, matchReason: 'Detected indicators of airway secretions, abnormal auscultation or breathlessness.' });
    }
    if (text.includes('fever') || text.includes('temp') || text.includes('wound') || text.includes('catheter') || text.includes('incision') || text.includes('redness')) {
      const diag = diagnoses.find(d => d.code === '00004'); // Risk for Infection
      if (diag) suggestions.push({ ...diag, matchReason: 'Detected primary barrier breakdown (wound/catheter) or temperature fluctuations.' });
    }
    if (text.includes('weak') || text.includes('walk') || text.includes('fall') || text.includes('cane') || text.includes('bed') || text.includes('mobility')) {
      const diag = diagnoses.find(d => d.code === '00085'); // Impaired Physical Mobility
      if (diag) suggestions.push({ ...diag, matchReason: 'Detected limitation of physical independence or strength constraints.' });
    }
    if (text.includes('anxious') || text.includes('worry') || text.includes('fear') || text.includes('nervous') || text.includes('stress')) {
      const diag = diagnoses.find(d => d.code === '00146'); // Anxiety
      if (diag) suggestions.push({ ...diag, matchReason: 'Detected symptoms of autonomic apprehension or verbalized stress.' });
    }

    // Default fallback if no match
    if (suggestions.length === 0 && diagnoses.length > 0) {
      suggestions.push({
        ...diagnoses[0],
        matchReason: 'General diagnosis suggestion for initial nursing process outline.'
      });
    }

    return res.json({ suggestions });
  } catch (err) {
    return res.status(500).json({ error: 'AI diagnosis generation failed' });
  }
}

// Generate SMART Goals
export async function generateGoals(req: AuthenticatedRequest, res: Response) {
  try {
    const { diagnosisName } = req.body;
    if (!diagnosisName) {
      return res.status(400).json({ error: 'Diagnosis name is required' });
    }

    // SMART goals templates based on diagnosis
    let goals = [];
    if (diagnosisName.includes('Acute Pain')) {
      goals = [
        {
          type: 'short-term',
          text: 'Patient will report a pain score reduction to 3/10 or lower within 1 hour after receiving prescribed analgesic.',
          framework: { S: 'Pain level reduction', M: 'Scale score (0-10)', A: 'Realistic with analgesics', R: 'Direct pain management link', T: 'Within 1 hour' }
        },
        {
          type: 'long-term',
          text: 'Patient will independently demonstrate 2 non-pharmacological relaxation techniques by day of discharge to manage sudden pain flares.',
          framework: { S: 'Relaxation techniques demo', M: 'Count of 2 techniques', A: 'Requires patient teaching', R: 'Long-term self-care capability', T: 'By day of discharge' }
        }
      ];
    } else if (diagnosisName.includes('Airway Clearance')) {
      goals = [
        {
          type: 'short-term',
          text: 'Patient will maintain clear breath sounds on auscultation and expectorate secretions effectively within 8 hours.',
          framework: { S: 'Clear breath sounds & expectoration', M: 'Auscultatory clearance', A: 'Expected with coughing/hydration', R: 'Airway patency priority', T: 'Within 8 hours' }
        },
        {
          type: 'long-term',
          text: 'Patient will maintain oxygen saturation levels above 94% on room air at all times by the end of 48 hours.',
          framework: { S: 'SpO2 maintenance', M: '>= 94% on pulse oximeter', A: 'Realistic for resolving pulmonary conditions', R: 'Ventilatory efficiency indicator', T: 'Within 48 hours' }
        }
      ];
    } else if (diagnosisName.includes('Infection')) {
      goals = [
        {
          type: 'short-term',
          text: 'Patient will maintain temperature within normal range (97.8°F to 99.1°F) during the shift (next 12 hours).',
          framework: { S: 'Core temperature normalization', M: 'Thermometer readings', A: 'Acheivable with basic monitoring/cooling', R: 'Key sign of systemic infection', T: 'During the 12-hour shift' }
        },
        {
          type: 'long-term',
          text: 'Patient\'s surgical wound site will remain free from purulent drainage, extreme redness, or swelling throughout the admission.',
          framework: { S: 'Surgical wound inspection parameters', M: 'Absence of exudate/swelling/redness', A: 'Requires aseptic dressing care', R: 'Direct indicator of local healing', T: 'Throughout admission' }
        }
      ];
    } else {
      // General SMART goal generator
      goals = [
        {
          type: 'short-term',
          text: `Patient will achieve baseline functional parameters related to ${diagnosisName} within 24 hours of care plan execution.`,
          framework: { S: `Improvement in ${diagnosisName}`, M: 'Observable baseline assessment', A: 'Achievable', R: 'Directly linked to clinical needs', T: 'Within 24 hours' }
        },
        {
          type: 'long-term',
          text: `Patient will demonstrate complete resolution or effective management of ${diagnosisName} by the day of planned discharge.`,
          framework: { S: `Management of ${diagnosisName}`, M: 'Patient demonstration/verbalization', A: 'Realistic at discharge', R: 'Pre-discharge safety check', T: 'By day of discharge' }
        }
      ];
    }

    return res.json({ goals });
  } catch (err) {
    return res.status(500).json({ error: 'AI Goal generation failed' });
  }
}

// Generate evidence-based Interventions & Rationales
export async function generateInterventions(req: AuthenticatedRequest, res: Response) {
  try {
    const { diagnosisName } = req.body;
    if (!diagnosisName) {
      return res.status(400).json({ error: 'Diagnosis name is required' });
    }

    let interventions = [];
    if (diagnosisName.includes('Acute Pain')) {
      interventions = [
        {
          description: 'Assess pain location, character, and intensity using 0-10 numerical scale every 4 hours.',
          priority: 'high',
          rationale: 'Establishes a baseline, monitors trend, and determines timing and efficacy of therapeutic response.',
          evidenceLevel: 'Level I (Meta-analysis of RCTs)'
        },
        {
          description: 'Administer ordered analgesics (such as NSAIDs or opioids) promptly as scheduled or PRN.',
          priority: 'high',
          rationale: 'Pharmacological agents block pain pathways at central or peripheral sites to achieve rapid relief.',
          evidenceLevel: 'Level I (Clinical Practice Guideline)'
        },
        {
          description: 'Reposition patient using supportive pillows to promote physiological alignment and ease incision tension.',
          priority: 'medium',
          rationale: 'Reduces muscular guarding, decreases localized pressure points, and enhances perfusion to ischemic areas.',
          evidenceLevel: 'Level III (Expert Consensus Panel)'
        }
      ];
    } else if (diagnosisName.includes('Airway Clearance')) {
      interventions = [
        {
          description: 'Auscultate breath sounds and monitor respiratory rate/depth every 2 to 4 hours.',
          priority: 'high',
          rationale: 'Identifies presence of abnormal sounds (crackles/wheezes) representing fluid or bronchial constriction.',
          evidenceLevel: 'Level I (Systematic Review)'
        },
        {
          description: 'Instruct and assist patient to practice coughing and deep-breathing exercises every 2 hours.',
          priority: 'high',
          rationale: 'Splints airways, expands collapsed alveoli, and mobilizes secretions upward into trachea for expectoration.',
          evidenceLevel: 'Level I (RCT Evidence)'
        },
        {
          description: 'Increase oral hydration to 2.5 Liters daily unless contraindicated by cardiac/renal conditions.',
          priority: 'medium',
          rationale: 'Liquefies thick mucus secretions within respiratory passages, making them significantly easier to mobilize.',
          evidenceLevel: 'Level II (Cohort Studies)'
        }
      ];
    } else {
      interventions = [
        {
          description: `Monitor clinical parameters closely related to ${diagnosisName} once every shift.`,
          priority: 'high',
          rationale: 'Ongoing assessment provides objective indicators of changes in patient health status.',
          evidenceLevel: 'Level III (Expert Opinion)'
        },
        {
          description: `Educate patient and caregivers regarding secondary management of ${diagnosisName} symptoms.`,
          priority: 'medium',
          rationale: 'Patient education improves self-care, increases health literacy, and prevents post-discharge relapse.',
          evidenceLevel: 'Level II (Randomized Trials)'
        }
      ];
    }

    return res.json({ interventions });
  } catch (err) {
    return res.status(500).json({ error: 'AI Interventions generation failed' });
  }
}

// AI Care Plan Reviewer
export async function reviewCarePlan(req: AuthenticatedRequest, res: Response) {
  try {
    const { subjectiveData, objectiveData, nursingDiagnosis, shortTermGoals, longTermGoals, interventions } = req.body;

    const issues: { type: 'critical' | 'warning' | 'info'; section: string; message: string; fix: string }[] = [];
    let score = 100;

    // Check 1: Incomplete Assessment
    if (!subjectiveData || subjectiveData.trim().length < 15) {
      issues.push({
        type: 'warning',
        section: 'Assessment (Subjective)',
        message: 'Subjective details are very brief. Clinical context might be missing.',
        fix: 'Add patient complaints, pain verbalizations, or historical symptoms in their own words.'
      });
      score -= 10;
    }
    if (!objectiveData || !objectiveData.includes('/') || objectiveData.trim().length < 15) {
      // Simple vital check: e.g. blood pressure like 120/80
      issues.push({
        type: 'critical',
        section: 'Assessment (Objective)',
        message: 'No clear vital signs or lab parameters identified (e.g., Blood Pressure, SpO2, Temp).',
        fix: 'Enter complete vitals like BP, HR, RR, Temp, and SpO2 in the objective section.'
      });
      score -= 15;
    }

    // Check 2: No diagnoses selected
    let diagList = [];
    try {
      diagList = typeof nursingDiagnosis === 'string' ? JSON.parse(nursingDiagnosis) : nursingDiagnosis || [];
    } catch(e) {}
    if (!diagList || diagList.length === 0) {
      issues.push({
        type: 'critical',
        section: 'Nursing Diagnosis',
        message: 'No NANDA diagnoses are attached to this care plan.',
        fix: 'Search the NANDA Library and select at least one active nursing diagnosis.'
      });
      score -= 20;
    }

    // Check 3: SMART Goal Checks
    let stGoals = [];
    let ltGoals = [];
    try {
      stGoals = typeof shortTermGoals === 'string' ? JSON.parse(shortTermGoals) : shortTermGoals || [];
      ltGoals = typeof longTermGoals === 'string' ? JSON.parse(longTermGoals) : longTermGoals || [];
    } catch(e) {}

    if (stGoals.length === 0) {
      issues.push({
        type: 'critical',
        section: 'Goals (Short-term)',
        message: 'Missing short-term goals.',
        fix: 'Create at least one short-term goal targetable within your current nursing shift.'
      });
      score -= 15;
    } else {
      // Check if goals have time metrics (e.g., hours, mins, days)
      stGoals.forEach((g: any, index: number) => {
        const text = (typeof g === 'string' ? g : g.text || '').toLowerCase();
        const hasTime = /\b(hour|hr|min|day|shift|week|discharge)\b/.test(text);
        if (!hasTime) {
          issues.push({
            type: 'warning',
            section: 'Goals (Short-term)',
            message: `Goal #${index + 1} ("${text.substring(0, 30)}...") does not appear to have a time boundary.`,
            fix: 'Update the goal with a SMART time constraint (e.g., "within 2 hours", "by end of shift").'
          });
          score -= 5;
        }
      });
    }

    // Check 4: Interventions checks
    let intList = [];
    try {
      intList = typeof interventions === 'string' ? JSON.parse(interventions) : interventions || [];
    } catch(e) {}

    if (intList.length === 0) {
      issues.push({
        type: 'critical',
        section: 'Interventions',
        message: 'No planned interventions recorded.',
        fix: 'Outline 2-3 specific nursing actions that address the selected diagnosis.'
      });
      score -= 15;
    } else {
      intList.forEach((i: any, index: number) => {
        const desc = (typeof i === 'string' ? i : i.description || '').toLowerCase();
        const rationale = (typeof i === 'string' ? '' : i.rationale || '').toLowerCase();
        if (desc.length < 10) {
          issues.push({
            type: 'warning',
            section: 'Interventions',
            message: `Intervention #${index + 1} is too vague.`,
            fix: 'Describe concrete nursing activities (e.g. state "Auscultate breath sounds every 4 hours" instead of "check lungs").'
          });
          score -= 5;
        }
        if (!rationale || rationale.length < 15) {
          issues.push({
            type: 'critical',
            section: 'Interventions (Rationale)',
            message: `Intervention #${index + 1} is missing a robust clinical rationale.`,
            fix: 'Add scientific reasoning justifying why this nursing intervention resolves the pathophysiology.'
          });
          score -= 10;
        }
      });
    }

    // Ensure score doesn't drop below 0
    score = Math.max(score, 0);

    return res.json({
      score,
      status: score >= 85 ? 'excellent' : score >= 70 ? 'good' : 'requires-improvement',
      issues
    });
  } catch (err) {
    return res.status(500).json({ error: 'AI Care Plan review audit failed' });
  }
}
