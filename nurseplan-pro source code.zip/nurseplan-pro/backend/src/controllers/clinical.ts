import { Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../config/db';
import { AuthenticatedRequest } from '../middleware/auth';

// Create Clinical Log
export async function createClinicalLog(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user || req.user.role !== 'student') {
      return res.status(403).json({ error: 'Only students can log clinical procedures.' });
    }

    const { procedureName, date, ward, supervisorName, reflectionNotes, competencyStatus, hours } = req.body;

    if (!procedureName || !date || !ward || !supervisorName || !competencyStatus || !hours) {
      return res.status(400).json({ error: 'Missing required log fields' });
    }

    const logId = uuidv4();
    const logHours = parseFloat(hours);

    // Save clinical log entry
    await query(
      `INSERT INTO clinical_logs (id, student_id, procedure_name, date, ward, supervisor_name, reflection_notes, competency_status, hours, approval_status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [
        logId,
        req.user.id,
        procedureName,
        date,
        ward,
        supervisorName,
        reflectionNotes || '',
        competencyStatus,
        logHours,
        'pending'
      ]
    );

    // Update logged hours totals on the student
    await query(
      'UPDATE students SET clinical_hours_logged = clinical_hours_logged + $1 WHERE id = $2',
      [logHours, req.user.id]
    );

    return res.status(201).json({ message: 'Clinical log saved successfully, pending instructor approval.', id: logId });
  } catch (err) {
    console.error('Create Clinical Log Error:', err);
    return res.status(500).json({ error: 'Failed to record clinical log' });
  }
}

// Get Clinical Logs (Student see theirs, instructors see pending for their school)
export async function getClinicalLogs(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

    let result;
    if (req.user.role === 'student') {
      result = await query(
        'SELECT * FROM clinical_logs WHERE student_id = $1 ORDER BY date DESC, created_at DESC',
        [req.user.id]
      );
    } else if (req.user.role === 'instructor') {
      // Instructors see logs from students in their school
      result = await query(
        `SELECT cl.*, u.name as student_name 
         FROM clinical_logs cl 
         JOIN users u ON cl.student_id = u.id 
         WHERE u.school_id = $1 ORDER BY cl.approval_status ASC, cl.date DESC`,
        [req.user.schoolId]
      );
    } else {
      // Admin sees all logs
      result = await query(
        `SELECT cl.*, u.name as student_name 
         FROM clinical_logs cl
         JOIN users u ON cl.student_id = u.id 
         WHERE u.school_id = $1 ORDER BY cl.date DESC`,
        [req.user.schoolId]
      );
    }

    return res.json(result.rows);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to query clinical logs' });
  }
}

// Approve / Reject Clinical Log (Instructor workflow)
export async function approveClinicalLog(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user || req.user.role !== 'instructor') {
      return res.status(403).json({ error: 'Only instructors can review clinical logs.' });
    }

    const { id } = req.params;
    const { status } = req.body; // 'approved' or 'rejected'

    if (status !== 'approved' && status !== 'rejected') {
      return res.status(400).json({ error: "Status must be 'approved' or 'rejected'" });
    }

    // Retrieve original log to check hours and student details
    const logCheck = await query(
      `SELECT cl.hours, cl.student_id, cl.approval_status, cl.procedure_name, u.school_id 
       FROM clinical_logs cl 
       JOIN users u ON cl.student_id = u.id 
       WHERE cl.id = $1`,
      [id]
    );

    if (logCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Clinical log not found' });
    }

    const log = logCheck.rows[0];

    if (log.school_id !== req.user.schoolId) {
      return res.status(403).json({ error: 'Access denied: student is not enrolled in your school.' });
    }

    if (log.approval_status !== 'pending') {
      return res.status(400).json({ error: 'Clinical log has already been processed.' });
    }

    // Update log status
    await query(
      `UPDATE clinical_logs SET 
       approval_status = $1, 
       approved_by_id = $2, 
       approved_at = CURRENT_TIMESTAMP 
       WHERE id = $3`,
      [status, req.user.id, id]
    );

    // If approved, increment approved hours in students table
    if (status === 'approved') {
      await query(
        'UPDATE students SET clinical_hours_approved = clinical_hours_approved + $1 WHERE id = $2',
        [parseFloat(log.hours), log.student_id]
      );
    }

    // Notify Student
    await query(
      'INSERT INTO notifications (id, user_id, title, message, type) VALUES ($1, $2, $3, $4, $5)',
      [
        uuidv4(),
        log.student_id,
        status === 'approved' ? 'Clinical Log Approved' : 'Clinical Log Rejected',
        `Your clinical log for "${log.procedure_name}" has been ${status} by Dr. Jenkins.`,
        'approval'
      ]
    );

    return res.json({ message: `Clinical log ${status} successfully` });
  } catch (err) {
    console.error('Approve Log Error:', err);
    return res.status(500).json({ error: 'Failed to process clinical log approval' });
  }
}
