import { Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../config/db';
import { AuthenticatedRequest } from '../middleware/auth';

// 1. Patient Controllers (HIPAA Compliant)
export async function createPatient(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user || req.user.role !== 'student') {
      return res.status(403).json({ error: 'Only students can manage patient logs.' });
    }

    const { initials, age, gender, ward, bedNumber, admissionDate, medicalDiagnosis, historyOfPresentIllness, allergies, currentMedications, notes } = req.body;

    if (!initials || !age || !gender || !ward || !bedNumber || !admissionDate || !medicalDiagnosis) {
      return res.status(400).json({ error: 'Missing core patient details' });
    }

    const patientId = uuidv4();
    await query(
      `INSERT INTO patients (id, initials, age, gender, ward, bed_number, admission_date, medical_diagnosis, 
      history_of_present_illness, allergies, current_medications, notes, student_id) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
      [
        patientId,
        initials.toUpperCase().substring(0, 3), // Enforce initials only
        parseInt(age),
        gender,
        ward,
        bedNumber,
        admissionDate,
        medicalDiagnosis,
        historyOfPresentIllness || '',
        allergies || '',
        currentMedications || '',
        notes || '',
        req.user.id,
      ]
    );

    return res.status(201).json({ message: 'Patient profile created', id: patientId });
  } catch (err) {
    console.error('Create Patient Error:', err);
    return res.status(500).json({ error: 'Failed to create patient profile' });
  }
}

export async function getPatients(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

    let result;
    if (req.user.role === 'student') {
      result = await query('SELECT * FROM patients WHERE student_id = $1 ORDER BY created_at DESC', [req.user.id]);
    } else {
      // Instructors and admins see all patients in the school
      result = await query(
        `SELECT p.*, u.name as student_name FROM patients p 
         JOIN users u ON p.student_id = u.id 
         WHERE u.school_id = $1 ORDER BY p.created_at DESC`,
        [req.user.schoolId]
      );
    }

    return res.json(result.rows);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to query patients list' });
  }
}

// 2. Care Plan Controllers
export async function createCarePlan(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user || req.user.role !== 'student') {
      return res.status(403).json({ error: 'Only students can create care plans' });
    }

    const { patientId, title } = req.body;
    if (!patientId || !title) {
      return res.status(400).json({ error: 'Patient ID and care plan title are required' });
    }

    // Verify patient belongs to student
    const patientCheck = await query('SELECT id FROM patients WHERE id = $1 AND student_id = $2', [patientId, req.user.id]);
    if (patientCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Patient profile not found or access denied' });
    }

    const carePlanId = uuidv4();
    await query(
      `INSERT INTO care_plans (id, patient_id, student_id, title, status, subjective_data, objective_data, 
       nursing_diagnosis, short_term_goals, long_term_goals, interventions, implementation_notes, evaluation_status, evaluation_notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
      [carePlanId, patientId, req.user.id, title, 'draft', '', '', '[]', '[]', '[]', '[]', '', null, '']
    );

    return res.status(201).json({ message: 'Care plan draft created', id: carePlanId });
  } catch (err) {
    console.error('Create Care Plan Error:', err);
    return res.status(500).json({ error: 'Failed to create care plan' });
  }
}

export async function getCarePlans(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

    let result;
    if (req.user.role === 'student') {
      result = await query(
        `SELECT cp.*, p.initials as patient_initials, p.medical_diagnosis 
         FROM care_plans cp 
         JOIN patients p ON cp.patient_id = p.id 
         WHERE cp.student_id = $1 ORDER BY cp.updated_at DESC`,
        [req.user.id]
      );
    } else if (req.user.role === 'instructor') {
      // Instructors see all non-draft care plans submitted within their school
      result = await query(
        `SELECT cp.*, p.initials as patient_initials, p.medical_diagnosis, u.name as student_name, g.total_score 
         FROM care_plans cp 
         JOIN patients p ON cp.patient_id = p.id 
         JOIN users u ON cp.student_id = u.id 
         LEFT JOIN grades g ON cp.id = g.care_plan_id
         WHERE u.school_id = $1 AND cp.status != 'draft' 
         ORDER BY cp.submitted_at DESC`,
        [req.user.schoolId]
      );
    } else {
      // Admin sees everything in school
      result = await query(
        `SELECT cp.*, p.initials as patient_initials, u.name as student_name 
         FROM care_plans cp
         JOIN patients p ON cp.patient_id = p.id 
         JOIN users u ON cp.student_id = u.id 
         WHERE u.school_id = $1 ORDER BY cp.updated_at DESC`,
        [req.user.schoolId]
      );
    }

    return res.json(result.rows);
  } catch (err) {
    console.error('Get Care Plans Error:', err);
    return res.status(500).json({ error: 'Failed to retrieve care plans' });
  }
}

export async function getCarePlanById(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

    const { id } = req.params;
    const cpResult = await query(
      `SELECT cp.*, p.initials as patient_initials, p.age as patient_age, p.gender as patient_gender, 
       p.ward as patient_ward, p.bed_number as patient_bed, p.admission_date as patient_admission_date,
       p.medical_diagnosis as patient_medical_diagnosis, p.history_of_present_illness, p.allergies, p.current_medications,
       u.name as student_name
       FROM care_plans cp 
       JOIN patients p ON cp.patient_id = p.id 
       JOIN users u ON cp.student_id = u.id
       WHERE cp.id = $1`,
      [id]
    );

    if (cpResult.rows.length === 0) {
      return res.status(404).json({ error: 'Care plan not found' });
    }

    const carePlan = cpResult.rows[0];

    // Check permissions: Student must own the plan, or instructors/admins must be from the same school
    if (req.user.role === 'student' && carePlan.student_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied to this care plan' });
    }

    // Get grading breakdown if graded
    let gradeDetails = null;
    if (carePlan.status === 'reviewed') {
      const gradeResult = await query('SELECT * FROM grades WHERE care_plan_id = $1', [id]);
      if (gradeResult.rows.length > 0) {
        gradeDetails = gradeResult.rows[0];
      }
    }

    return res.json({ carePlan, gradeDetails });
  } catch (err) {
    console.error('Get Care Plan Details Error:', err);
    return res.status(500).json({ error: 'Failed to query care plan details' });
  }
}

// Auto Save / Update draft
export async function updateCarePlan(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

    const { id } = req.params;
    const {
      title,
      subjectiveData,
      objectiveData,
      nursingDiagnosis,
      shortTermGoals,
      longTermGoals,
      interventions,
      implementationNotes,
      evaluationStatus,
      evaluationNotes
    } = req.body;

    // Verify ownership
    const checkResult = await query('SELECT student_id, status FROM care_plans WHERE id = $1', [id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ error: 'Care plan not found' });
    }

    const currentPlan = checkResult.rows[0];
    if (req.user.role === 'student' && currentPlan.student_id !== req.user.id) {
      return res.status(403).json({ error: 'Forbidden: You do not own this care plan' });
    }

    if (currentPlan.status === 'submitted' && req.user.role === 'student') {
      return res.status(400).json({ error: 'Cannot update a submitted care plan' });
    }

    await query(
      `UPDATE care_plans SET 
       title = COALESCE($1, title), 
       subjective_data = COALESCE($2, subjective_data),
       objective_data = COALESCE($3, objective_data),
       nursing_diagnosis = COALESCE($4, nursing_diagnosis),
       short_term_goals = COALESCE($5, short_term_goals),
       long_term_goals = COALESCE($6, long_term_goals),
       interventions = COALESCE($7, interventions),
       implementation_notes = COALESCE($8, implementation_notes),
       evaluation_status = COALESCE($9, evaluation_status),
       evaluation_notes = COALESCE($10, evaluation_notes),
       updated_at = CURRENT_TIMESTAMP
       WHERE id = $11`,
      [
        title,
        subjectiveData,
        objectiveData,
        nursingDiagnosis,
        shortTermGoals,
        longTermGoals,
        interventions,
        implementationNotes,
        evaluationStatus,
        evaluationNotes,
        id
      ]
    );

    return res.json({ message: 'Care plan auto-saved successfully' });
  } catch (err) {
    console.error('Update Care Plan Error:', err);
    return res.status(500).json({ error: 'Failed to update care plan' });
  }
}

// Submit Assignment
export async function submitCarePlan(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user || req.user.role !== 'student') {
      return res.status(403).json({ error: 'Only students can submit assignments' });
    }

    const { id } = req.params;

    const check = await query('SELECT student_id, status FROM care_plans WHERE id = $1', [id]);
    if (check.rows.length === 0) return res.status(404).json({ error: 'Care plan not found' });
    if (check.rows[0].student_id !== req.user.id) return res.status(403).json({ error: 'Access denied' });

    await query(
      "UPDATE care_plans SET status = 'submitted', submitted_at = CURRENT_TIMESTAMP WHERE id = $1",
      [id]
    );

    // Alert instructors
    const schoolInstructors = await query("SELECT id FROM users WHERE school_id = $1 AND role = 'instructor'", [req.user.schoolId]);
    for (const inst of schoolInstructors.rows) {
      await query(
        'INSERT INTO notifications (id, user_id, title, message, type) VALUES ($1, $2, $3, $4, $5)',
        [
          uuidv4(),
          inst.id,
          'Care Plan Submitted',
          `Student has submitted a care plan for review.`,
          'submission'
        ]
      );
    }

    return res.json({ message: 'Care plan submitted to instructor successfully' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to submit care plan' });
  }
}

// Grade Assignment (10 points per section)
export async function gradeCarePlan(req: AuthenticatedRequest, res: Response) {
  try {
    if (!req.user || req.user.role !== 'instructor') {
      return res.status(403).json({ error: 'Only instructors can grade care plans' });
    }

    const { id } = req.params;
    const { assessmentScore, diagnosisScore, goalsScore, interventionsScore, evaluationScore, feedback, revisionRequired } = req.body;

    const check = await query(
      `SELECT cp.student_id, cp.title, u.school_id 
       FROM care_plans cp 
       JOIN users u ON cp.student_id = u.id 
       WHERE cp.id = $1`,
      [id]
    );
    if (check.rows.length === 0) return res.status(404).json({ error: 'Care plan not found' });
    if (check.rows[0].school_id !== req.user.schoolId) return res.status(403).json({ error: 'Permission denied' });

    const total = parseFloat(assessmentScore) + parseFloat(diagnosisScore) + parseFloat(goalsScore) + parseFloat(interventionsScore) + parseFloat(evaluationScore);
    const newStatus = revisionRequired ? 'revision_requested' : 'reviewed';

    // Update care plan state
    await query(
      `UPDATE care_plans SET 
       status = $1, 
       grade = $2, 
       instructor_feedback = $3, 
       revision_notes = $4,
       graded_at = CURRENT_TIMESTAMP 
       WHERE id = $5`,
      [newStatus, total, feedback || '', revisionRequired ? feedback : '', id]
    );

    // Save detailed rubric grades
    const gradeId = uuidv4();
    await query(
      `INSERT INTO grades (id, care_plan_id, instructor_id, assessment_score, diagnosis_score, goals_score, interventions_score, evaluation_score, total_score, feedback) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       ON CONFLICT (care_plan_id) DO UPDATE SET 
       instructor_id = EXCLUDED.instructor_id,
       assessment_score = EXCLUDED.assessment_score,
       diagnosis_score = EXCLUDED.diagnosis_score,
       goals_score = EXCLUDED.goals_score,
       interventions_score = EXCLUDED.interventions_score,
       evaluation_score = EXCLUDED.evaluation_score,
       total_score = EXCLUDED.total_score,
       feedback = EXCLUDED.feedback`,
      [
        gradeId,
        id,
        req.user.id,
        parseFloat(assessmentScore),
        parseFloat(diagnosisScore),
        parseFloat(goalsScore),
        parseFloat(interventionsScore),
        parseFloat(evaluationScore),
        total,
        feedback || ''
      ]
    );

    // Notify student
    await query(
      'INSERT INTO notifications (id, user_id, title, message, type) VALUES ($1, $2, $3, $4, $5)',
      [
        uuidv4(),
        check.rows[0].student_id,
        revisionRequired ? 'Revision Requested' : 'Care Plan Graded',
        revisionRequired 
          ? `Your care plan "${check.rows[0].title}" requires revision. Feedback: ${feedback}`
          : `Your care plan "${check.rows[0].title}" has been graded: ${total}/50.`,
        'grade'
      ]
    );

    return res.json({ message: revisionRequired ? 'Revision requested' : 'Grading submitted successfully', totalScore: total });
  } catch (err) {
    console.error('Grading Error:', err);
    return res.status(500).json({ error: 'Failed to submit grade' });
  }
}

// 3. Diagnosis Library Search
export async function getDiagnoses(req: AuthenticatedRequest, res: Response) {
  try {
    const { query: q, category } = req.query;
    let sql = 'SELECT * FROM diagnoses';
    const params: any[] = [];

    if (q || category) {
      sql += ' WHERE';
      if (q && category) {
        sql += ' (name LIKE $1 OR code LIKE $1 OR signs_symptoms LIKE $1) AND category = $2';
        params.push(`%${q}%`, category);
      } else if (q) {
        sql += ' name LIKE $1 OR code LIKE $1 OR signs_symptoms LIKE $1';
        params.push(`%${q}%`);
      } else {
        sql += ' category = $1';
        params.push(category);
      }
    }

    sql += ' ORDER BY name ASC';
    const result = await query(sql, params);
    return res.json(result.rows);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to search diagnoses library' });
  }
}

export async function getDiagnosisById(req: AuthenticatedRequest, res: Response) {
  try {
    const { id } = req.params;
    const result = await query('SELECT * FROM diagnoses WHERE id = $1', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Diagnosis not found' });
    return res.json(result.rows[0]);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to retrieve diagnosis details' });
  }
}
